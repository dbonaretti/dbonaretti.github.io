#include<stdio.h>
#include<string.h>
#include<stdlib.h>
 
#define flag(x)	printf("FLAG %s\n",#x);

#define BUFFERDIM 16

/* ---------------------------------------
	GLOBAL VARS AND STACKS
--------------------------------------- */

unsigned int data[32];
double real[32];
unsigned int stack[32];
unsigned char user[1024];

unsigned int voice_num=0;
unsigned int last_voice = 0;

unsigned int up  = 0;
unsigned int ip  = 0;
unsigned int sp  = 0; 
unsigned int dsp = 0;

#define RED( x ) ( (x) & 0x001F )
#define GET_INT( address ) 	   (*(int *)(address))
#define PUT_INT( address, target ) {GET_INT(address)=target;}

#define Succ   data[ RED( dsp)]
#define First  data[ RED( dsp-1)]
#define Second data[ RED( dsp-2)]
#define Third  data[ RED( dsp-3)]

/* ---------------------------------------
	VIRTUAL MACHINE PRIMITIVES
--------------------------------------- */

void dec()	{ First--; }
void inc()	{ First++; }
void xor()	{ Second^= First; dsp--; }
void add()	{ Second += First; dsp--; }
void sub()	{ Second -= First; dsp--; }
void mul()	{ Second *= First; dsp--; }
void divide()	{ Second /= First; dsp--; }
void eq()	{ Second = !(Second == First); dsp--; }
void rpush()	{ stack[sp++] = First; dsp--; }
void rpop()	{ Succ = (int) stack[--sp]; dsp++; }
void rcpy()	{ Succ = (int) stack[sp-1]; dsp++; }
void dup()	{ Succ = First; dsp++; }
void over()	{ Succ = Second; dsp++; }
void swap()	{ int eax; eax = First; First = Second; Second = eax; }
void call()	{ stack[ sp++] = ip+sizeof(int); ip = GET_INT(user+ip);}
void execute()	{ stack[ sp++] = ip; ip = First; dsp--; }
void jmp_until(){ if(First!=0){ ip = GET_INT(user+ip); } else { ip+=sizeof(int);}  dsp--; }
void jmp()	{ ip = GET_INT(user+ip);}
void ret()	{ ip = stack[ --sp]; }
void emit()	{ putchar(First); dsp--; }
void key()	{ Succ = fgetc(stdin); dsp++; }
void load()	{ Succ = GET_INT( user+ip); ip += sizeof(int);  dsp++; }
void cfetch()	{ First = (int) user[First]; }
void cstore()	{ user[First] = Second; dsp-=2; }
void drop()	{ dsp--; }

void uset()	{ up = First; dsp--; }
void here() 	{ Succ = up; dsp++; }

void or() 	{ Second ^= First; dsp--;}
void and() 	{ Second &= First; dsp--;}
void not() 	{ First = ~First; }

void *prim_array[] = {
	dec, inc, xor, add, 
	sub, mul, divide, eq, 
	rpush, rpop, rcpy, dup, 
	over, swap, call, execute,
	jmp_until, jmp, ret, 
	emit, key, load, cfetch, 
	cstore, drop, here, uset,
	or, and, not,
};

enum {
	DEC, INC, XOR, ADD, 
	SUB, MUL, DIVIDE, EQ, 
	RPUSH, RPOP, RCPY, DUP, 
	OVER, SWAP, CALL, EXECUTE,
	JMP_UNTIL, JMP, RET, 
	EMIT, KEY, LOAD, CFETCH, 
	CSTORE, DROP, HERE, USET,
	OR, AND, NOT,
};

void run_prim( unsigned int n)
{
	void (*f)();

	f = prim_array[n];
	(*f)();
}
