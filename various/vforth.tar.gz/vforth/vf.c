#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define GET_INT( address ) 	   (*(int *)(address))
#define PUT_INT( address, target ) {GET_INT(address)=target;}
#define RED( x ) ( (x) & 0x001F )

#define Succ   data[ RED( dsp)]
#define First  data[ RED( dsp-1)]
#define Second data[ RED( dsp-2)]
#define Third  data[ RED( dsp-3)]

extern unsigned int data[];
extern double real[];
extern unsigned int stack[];
extern unsigned char user[];

extern unsigned int voice_num;
extern unsigned int last_voice;

extern unsigned int up;
extern unsigned int ip;
extern unsigned int sp; 
extern unsigned int dsp;
extern unsigned int fsp; 

void dpush( unsigned int v) { Succ = v; dsp++; }
unsigned int dpop() { dsp--; return Succ; }
 
#define flag(x)	printf("FLAG %s\n",#x);

#define BUFFERDIM 16

extern void run_prim( unsigned int n);

enum {
	DEC, INC, XOR, ADD, 
	SUB, MUL, DIVIDE, EQ, 
	RPUSH, RPOP, RCPY, DUP, 
	OVER, SWAP, CALL, EXECUTE,
	JMP_UNTIL, JMP, RET, 
	EMIT, KEY, LOAD, CFETCH, 
	CSTORE, DROP, HERE, USET,
	OR, AND, NOT,
};

/* ---------------------------------------
	AUX PARSER 
--------------------------------------- */

static char whitep(char c)
{
	return ( c == ' ' || c == '\t' || c == '\n');
}

static char buffer[BUFFERDIM+1]={0};

void clean_buffer()
{
	int k = BUFFERDIM;
	while(k--)
		buffer[k] = 0;
}

void error( unsigned int k);

void nextw()
{
	char current_key;
	int j=0;

	clean_buffer();

	do{
		current_key = fgetc( stdin);
	}while( whitep( current_key));

	while( !whitep( current_key)){
		if( j<BUFFERDIM )
			buffer[j++]= current_key;
		else{
			error( 0 );
			return;
		}
		current_key = fgetc( stdin);
	}
}

void nextnl()
{
	char current_key;
	do{
		current_key = fgetc( stdin);
	}while( current_key != '\n');
}

char cmp_word( char *w)
{
	return strncmp( w, buffer, BUFFERDIM) == 0;
}

/* ---------------------------------------
	AUX PLACING ROUTINES
--------------------------------------- */

void nplace( unsigned int m){ user[up++] = m; }
void iplace( unsigned int m){ PUT_INT( &user[up], m); up+=sizeof(int); }

void splace( char *s, int dim)
{
	int k = 0;
	while( k<dim)
		nplace(s[k++]);
}


/* ---------------------------------------
	AUX USER DICTIONARY RUNNING 
--------------------------------------- */


int lse;
int lsee;
void save_user_state()		{ lsee= last_voice; lse = up; }
void restore_user_state()	{ up = lse; last_voice = lsee; }

#define pick_name( v)	( v+sizeof(int))
#define pick_run( v) 	( pick_name(v)+ BUFFERDIM)
#define pick_com( v)	( pick_run(v)+1)
#define pick_text( v) 	( pick_com(v)+1)

#define get_name_address(v)	pick_name( v)
#define get_next_voice(v)	GET_INT( user+v)
#define get_run_flag(v)		user[ pick_run( v)]
#define get_com_flag(v)		user[ pick_com( v)]
#define get_code_address(v)	pick_text( v)


char cm;
void com_mode()		{ cm = 1; }
void run_mode()		{ cm = 0; }


void run_voice( unsigned int v)
{
	ip =  get_code_address( v);
	sp++;
	do{
		run_prim(user[ip++]);
	}while(sp>0);
}
void clone( unsigned int k)
{
	while( user[k]!=RET)
		nplace( user[k++]);
}


void error( unsigned int k)
{
	if(cm){
		voice_num--;
		restore_user_state();
		nextnl();
	}
	run_mode();
	printf("%s ?\n",buffer);
}

void load_ref( unsigned int k)
{
	dpush( get_code_address(k));
}

void make_call_ref( unsigned int k)
{
	nplace( CALL);
	iplace( get_code_address(k));
}
void make_load_ref( unsigned int k)
{
	nplace( LOAD);
	iplace( get_code_address(k));
}

enum {
	RUN_VOICE, LOAD_REF, CLONE, ERROR, MAKE_CALL_REF, MAKE_LOAD_REF, 
};

void *action_table[] = {
	run_voice,
	load_ref,
	clone,
	error,
	make_call_ref,
	make_load_ref
};

void execute_action(int n, unsigned int v)
{
	void (*f)();
	f = action_table[n];
	(*f)(v);
}

char look_user_voice( int *out, int *out2)
{
	unsigned int k = voice_num;
	unsigned int v = last_voice;
	unsigned int p = up;

	while( k--){
		if( cmp_word(user+get_name_address(v))){
			(*out) = v;
			(*out2) = p;
			return 1;
		}
		p = v;
		v = get_next_voice( v);
	}

	return 0;
}

void run_user_voice( unsigned int v)
{
	char n;

	if(cm){
		n = get_com_flag(v);
	}else
		n = get_run_flag(v);

	execute_action( n, v);
}

/* ---------------------------------------
	AUX BUILDER FUNCTIONS
--------------------------------------- */

void allot() { up+= First; dsp--; }

void begin_compile( unsigned int k)
{
	dpush(up);
}
void until_compile( unsigned int k)
{
	nplace( JMP_UNTIL);
	iplace( First); dsp--;
}
void if_compile( unsigned int k)
{
	nplace( JMP_UNTIL);
	dpush(up);
	iplace( 0 );
}
void then_compile( unsigned int k)
{
	k = dpop();
	PUT_INT(user+k, up );
}


void load_num( unsigned int k)
{
	unsigned int n;

	nextw();
	n = atoi(buffer);
	dpush(n);
}

void compile_k( unsigned int k)
{
	nplace(LOAD);
	iplace(k);
}
void compile_num( unsigned int k)
{
	unsigned int n;

	nextw();
	n = atoi(buffer);

	nplace(LOAD);
	iplace(n);
}


void new_voice( char ra, char ca)
{
	save_user_state();
	voice_num++;

	int lv = last_voice;
	last_voice = up;

	iplace( lv );
	nextw();
	splace( buffer, BUFFERDIM);
	nplace( ra);
	nplace( ca);

}

void create( unsigned int k)
{
	new_voice( LOAD_REF, MAKE_LOAD_REF);
}

void start_def( unsigned int k)
{
	new_voice( RUN_VOICE,	MAKE_CALL_REF);
	com_mode();
}


/* DEBUG */

void *aname[] = {
	"RUN_VOICE", "LOAD_REF", "CLONE", "ERROR", "MAKE_CALL_REF", "MAKE_LOAD_REF", 
};
void print_header( int v)
{
	printf(" %d",  get_next_voice(v));
	printf(" %s",  user+get_name_address(v));
	printf(" %s",  aname[get_run_flag(v)]);
	printf(" %s\n",  aname[get_com_flag(v)]);
}

void *name[] =  {
	"DEC", "INC", "XOR", "ADD", 
	"SUB", "MUL", "DIVIDE", "EQ", 
	"RPUSH", "RPOP", "RCPY", "DUP", 
	"OVER", "SWAP", "CALL", "EXECUTE",
	"JMP_UNTIL", "JMP", "RET", 
	"EMIT", "KEY", "LOAD", "CFETCH", 
	"CSTORE", "DROP", "OR","AND","NOT",
};
void print_code( int v, int p) 
{
	v = get_code_address(v);

	while(v<p){
		printf("\t%s ", name[user[v]]);
		if( user[v] == CALL || user[v] == LOAD || user[v] == JMP || user[v] == JMP_UNTIL ){
			v++;
			printf("%d\n",GET_INT(user+v));
			v+=sizeof(int);
		}else{
			v++;
			putchar('\n');
		}
	}
}
void print_voice( int v, int p)
{
	print_header( v);
	print_code( v, p);
}

char look_user_voice( int *out, int *out2);

void list()
{
	int k = voice_num;
	unsigned int v = last_voice;

	while(k--){
		printf("--> %s\n", user+get_name_address(v));
		v = get_next_voice( v);
	}
}
void dump()
{
	int m;
	int p;
	nextw();

	if( look_user_voice( &m, &p))
		print_voice( m, p);
	else
		error(0);
}

void delete()
{
	unsigned int k = 1;
	unsigned int v = last_voice;
	nextw();
	while(k<= voice_num){
		if( cmp_word( user+get_name_address( v))){
			voice_num -= k;
			up = v;
			last_voice = get_next_voice( v);
			return;
		}
		k ++;
		v = get_next_voice( v);
	}
	printf("voice not found\n");
}

void end_def( unsigned int v)
{
	nplace( RET);
	run_mode();
}


int read_int( FILE *f)
{
	union {
		unsigned int i;
		unsigned char c[sizeof(int)];
	} u;

	int k = 0;
	while(k<sizeof(int))
		u.c[k++] = fgetc(f);

	return u.i;
}
void write_int( FILE *f, unsigned int m)
{
	union {
		unsigned int i;
		unsigned char c[sizeof(int)];
	} u ;

	u.i = m;

	int k = 0;
	while(k<sizeof(int))
		fputc( u.c[k++], f);
}

void load_mem()
{
	FILE *f;

	f = fopen("vf.save","r");

	if(f == NULL){
		printf("No memory found\n");
		return;
	}

	voice_num	= 	read_int(f);
	last_voice	= 	read_int(f);
	up		= 	read_int(f);

	int k = 0;
	while( k<up && !feof( f))
		user[k++] = fgetc(f);

	printf("user: %d bytes readen\n", k);

	fclose(f);
}
void save_mem()
{
	FILE *f;

	f = fopen("vf.save","w");
	

	write_int( f, voice_num);
	write_int( f, last_voice);
	write_int( f, up);

	int k =0;
	while(k<up){
		fputc( user[k++], f);
	}
	printf("user: %d bytes written\n", k);
	

	fclose(f);
}



void start_comm()
{
	int k = 1;
	char c;
	do{	
		c = fgetc(stdin);
		if( c=='(')
			k++;
		if( c==')')
			k--;
	}while(k);
}

void inner( unsigned int );

void end( unsigned int k)
{
	exit(0);
}

void say_words( unsigned int k);


struct voice {
	char *name;
	char code;
	void (*run_action)(unsigned int k);
	void (*com_action)(unsigned int k);

} core_table[] = {
	{ "NOT",	NOT,	dpush,	compile_k},
	{ "OR",		AND,	dpush,	compile_k},
	{ "USET",	USET,	dpush,	compile_k},
	{ "HERE",	HERE,	dpush,	compile_k},
	{ "DROP",	DROP,	dpush,	compile_k},
	{ "CSTORE",	CSTORE,	dpush,	compile_k},
	{ "CFETCH",	CFETCH,	dpush,	compile_k},
	{ "LOAD",	LOAD,	dpush,	compile_k},
	{ "KEY",	KEY,	dpush,	compile_k},
	{ "EMIT",	EMIT,	dpush,	compile_k},
	{ "RET",	RET,	dpush,	compile_k},
	{ "JMP",	JMP,	dpush,	compile_k},
	{ "JMP_UNTIL",	JMP_UNTIL,dpush,compile_k},
	{ "EXECUTE",	EXECUTE,dpush,	compile_k},
	{ "CALL",	CALL,	dpush,	compile_k},
	{ "SWAP",	SWAP,	dpush,	compile_k},
	{ "OVER",	OVER,	dpush,	compile_k},
	{ "DUP",	DUP,	dpush,	compile_k},
	{ "RCPY",	RCPY,	dpush,	compile_k},
	{ "RPUSH",	RPUSH,	dpush,	compile_k},
	{ "EQ",		EQ,	dpush,	compile_k},
	{ "DIVIDE",	DIVIDE,	dpush,	compile_k},
	{ "MUL",	MUL,	dpush,	compile_k},
	{ "SUB",	SUB,	dpush,	compile_k},
	{ "ADD",	ADD,	dpush,	compile_k},
	{ "XOR",	XOR,	dpush,	compile_k},
	{ "DEC",	DEC,	dpush,	compile_k},
	{ "INC",	INC,	dpush,	compile_k},


	{ "1+",		INC,	run_prim,	nplace},
	{ "1-",		DEC,	run_prim,	nplace},
	{ "xor",	XOR,	run_prim,	nplace},
	{ "+",		ADD,	run_prim,	nplace},
	{ "-",		SUB,	run_prim,	nplace},
	{ "*",		MUL,	run_prim,	nplace},
	{ "/",		DIVIDE,	run_prim,	nplace},
	{ "=",		EQ,	run_prim,	nplace},
	{ ">r",		RPUSH,	run_prim,	nplace},
	{ "r>",		RPOP,	run_prim,	nplace},
	{ "r@",		RCPY,	run_prim,	nplace},
	{ "dup",	DUP,	run_prim,	nplace},
	{ "drop",	DROP,	run_prim,	nplace},
	{ "over",	OVER,	run_prim,	nplace},
	{ "swap",	SWAP,	run_prim,	nplace},
	{ "execute",	EXECUTE,run_prim,	nplace},
	{ "emit",	EMIT,	run_prim,	nplace},
	{ "key",	KEY,	run_prim,	nplace},
	{ "c@",		CFETCH,	run_prim,	nplace},
	{ "c!",		CSTORE,	run_prim,	nplace},
	{ "here",	HERE,	run_prim,	nplace},
	{ "!u",		USET,	run_prim,	nplace},
	{ "or",		OR,	run_prim,	nplace},
	{ "and",	AND,	run_prim,	nplace},
	{ "not",	NOT,	run_prim,	nplace},
	{ "if",		0,	error,		if_compile },
	{ "then",	0,	error,		then_compile},
	{ "begin",	0,	error,		begin_compile},
	{ "until",	0,	error,		until_compile},
	{ ":",		0,	start_def,	error},
	{ ";",		0,	error,		end_def},
	{ "create", 	0,	create,		error},
	{ "dump", 	0,	dump,		error},
	{ "list",	0,	list,		error},
	{ "<int>",	0,	load_num,	compile_num},	
	{ "save",	0,	save_mem,	error },
	{ "load",	0,	load_mem,	error },
	{ "allot",	0,	allot,		error },
	{ "inner",	0,	inner,		inner },
	{ "[",		0,	run_mode,	run_mode },
	{ "]",		0,	com_mode,	com_mode },
	{ "delete",	0,	delete,		error },
	{ "(",		0,	start_comm,	start_comm },
	{ "end",	0,	end,		error },
	{ "words",	0,	say_words,	error },
	
};


void say_words( unsigned int k)
{
	int dim = (sizeof(core_table)/sizeof(struct voice));

	printf("list of primitive words:\n\n ");
	while(dim--)
		printf("%s ",core_table[dim].name);

	putchar('\n');
}

/* 
	------	AUX INNER DICTIONARY RUNNER -----
*/



char look_inner_voice( int *k)
{

	int dim = (sizeof(core_table)/sizeof(struct voice));

	while( dim--){
		if( cmp_word( core_table[dim].name)){	
			(*k) = dim;
			return 1;
		}
	}
	return 0;
}


void run_inner_voice( int n)
{

	void (*f)(unsigned int);
	if( cm)
		f = core_table[n].com_action;
	else
		f = core_table[n].run_action;

	(*f)( core_table[n].code);
}

void inner( unsigned int k)
{
	unsigned int m;
	nextw();

	if( look_inner_voice( &m))
		run_inner_voice( m);
	else
		error(0);
}

/* ---------------------------------------
		MAIN 
--------------------------------------- */

void handle_word()
{

	unsigned int m;
	unsigned int p;
	
	if( look_user_voice( &m, &p)){
		run_user_voice( m);
	}else if( look_inner_voice( &m)){
		run_inner_voice( m);
	}else{
		error(0);
	}
}

void forth()
{
	run_mode();
	while(1){
		nextw();
		handle_word();
		if(!cm)
			printf("\n\n( ok)\n\n");

	}
}

int main()
{
	forth();
	return 0;
}


/*
	ISC License

	Copyright 2025 Davide Bonaretti

	Permission to use, copy, modify, and/or distribute this 
	software for any purpose with or without fee is hereby 
	granted, provided that the above copyright notice and 
	this permission notice appear in all copies.
	
	THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
	DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
	INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
	FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
	SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
	ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
	OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
	NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
	IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
	SOFTWARE.
*/
