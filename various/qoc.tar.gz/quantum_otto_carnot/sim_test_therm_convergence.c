#include"./headers/test.h"
#include"./headers/ising.h"
#include"./headers/rafw.h"
#include<stdio.h>


extern void thermalization_cons_test( 
	int i,	
	int j, 
	double bath_temperature, 
	double fixed_tau, 
	double total_time, 
	double shot_time, 
	double dt, 
	double mod_coeff);

int main(int argc,char **argv)
{

	if(argc!=5){
		printf("sim_test_therm [sites] [mod coeff] [i] [j]  -- [time] [magic coeff]\n");
		return -1;
	}

	int sites=atoi(argv[1]);
	double mod_coeff=atof(argv[2]);
	int i= atoi(argv[3]);
	int j= atoi(argv[4]);

	InitMemory(sites*2,15);

	thermalization_cons_test(
        	i,j,		/* matrix coords */
        	10,		/* bath_temperature */
        	0.2,		/* fixed_tau */
        	0.005,		/* total_time */
        	0.0005,		/* shot_time */
        	0.000001,	/* dt */
        	mod_coeff);	/* mod_coeff */
	
	return 0;
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
