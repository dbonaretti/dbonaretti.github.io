#include"./headers/ising.h"

int main(int argc,char **argv)
{
	ising_sim(argc,argv,worked_imperfect_otto_cycle);
	return 0;
}
