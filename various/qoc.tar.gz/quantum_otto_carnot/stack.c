#include<stdlib.h>
#include<stdio.h>
#include"./headers/rafw.h"
#include"./headers/debug.h"

int StackIndex=0;

void *StackFirst()	{  return StackArray[check(StackIndex-1)];	}
void *StackSecond()	{  return StackArray[check(StackIndex-2)];	}
void *StackThird()	{  return StackArray[check(StackIndex-3)];	}
void *StackSucc()	{  return StackArray[check(StackIndex)];	}
void *StackSuccSucc()	{  return StackArray[check(StackIndex+1)];	}

void forij(
	void (*op)(double_complex *,double_complex *),
	void *A,
	void *B)
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];
	double_complex (*b)[MatrixDim][MatrixDim];
	a=A;
	b=B;

	for(i=0;i<MatrixDim;i++)
		for(j=0;j<MatrixDim;j++)
			(*op)(&(*a)[i][j],&(*b)[i][j]);
}
void copy_op	(double_complex *a, double_complex *b)  { (*a)=(*b);}


/* ----------------------------------------------
	BASIC STACK OPERATIONS 
------------------------------------------------*/

double DROP()
{
	check(--StackIndex);
}

void swapn(int a,int b)
{
	void *tmp;
	tmp=StackArray[a];
	StackArray[check(a)]=StackArray[check(b)];
	StackArray[b]=tmp;
}
void ROT()
{
	swapn(StackIndex-3,StackIndex-1);
	swapn(StackIndex-2,StackIndex-3);
}
void MROT()
{
	swapn(StackIndex-2,StackIndex-1);
	swapn(StackIndex-2,StackIndex-3);
}
void SWAP()
{
	swapn(StackIndex-1,StackIndex-2);
}
void NIP()
{
	SWAP(); DROP();
}
void SWAP_ZF()
{
	swapn(StackIndex-1,StackIndex);
}
void SWAP_ZS()
{
	swapn(StackIndex-2,StackIndex);
}


/* --- LOADING FUNCTIONS --- */


void ARG_FLOAD(double_complex (*mm)(int i,int j,void *args),void *args)
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];

	a=StackSucc();

	for(i=0;i<MatrixDim;i++)
		for(j=0;j<MatrixDim;j++)
			(*a)[i][j]=(mm)(i,j,args);
	StackIndex++;
}

void FLOAD(double_complex (*mm)(int i,int j))
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];

	a=StackSucc();

	for(i=0;i<MatrixDim;i++)
		for(j=0;j<MatrixDim;j++)
			(*a)[i][j]=(mm)(i,j);
	StackIndex++;
}



double random_real()
{
	return 10*(rand()%1000);
}
double complex random_complex()
{
	return random_real()+I*random_real();
}


void PERT_HLOAD(double_complex (*hm)(double time,int i,int j),double time)
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];
	srand(0);

	a=StackSucc();

	for(i=0;i<MatrixDim;i++)
		for(j=i;j<MatrixDim;j++){
			(*a)[i][j]=(*hm)(time,i,j)+random_complex();
			(*a)[j][i]=conj((*a)[i][j]);
		}
	StackIndex++;
}

void RANDOM_HERMITIAN()
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];
	srand(0);
	double_complex c;

	a=StackSucc();

	for(i=0;i<MatrixDim;i++)
		for(j=i;j<MatrixDim;j++){
			if(i==j)
				c = random_real();
			else
				c = random_complex();

			(*a)[i][j]=c;
			(*a)[j][i]=conj((*a)[i][j]);
		}
	StackIndex++;
}

void HLOAD(double_complex (*hm)(double time,int i,int j),double time)
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];
	srand(0);

	a=StackSucc();

	for(i=0;i<MatrixDim;i++)
		for(j=i;j<MatrixDim;j++){
			(*a)[i][j]=(*hm)(time,i,j); 
			(*a)[j][i]=conj((*a)[i][j]);
		}
	StackIndex++;
}
void THLOAD(double_complex (*hm)(double time,int i,int j),double time)
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];

	a=StackSucc();

	for(i=0;i<MatrixDim;i++)
		for(j=0;j<MatrixDim;j++)
			(*a)[i][j]=(*hm)(time,j,i);
	StackIndex++;
}

void STORE(void *mat) /* A -- A */
{
	forij(copy_op,mat,StackFirst());
}


void LOAD(void *mat)
{
	forij(copy_op,StackSucc(),mat);
	StackIndex++;
}

void TLOAD(void *mat)
{
	LOAD(mat); TRANS();
}

void DUP()	/* A -- A A */
{
	forij(copy_op,StackSucc(),StackFirst());
	StackIndex++;
}

void OVER()	/* A B -- A B A */
{
	forij(copy_op,StackSucc(),StackSecond());
	StackIndex++;
}

void PRINT_MATRIX() /* A -- A */
{
	print_matrix(StackFirst(),MatrixDim);
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
