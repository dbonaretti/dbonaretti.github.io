#include"./headers/rafw.h"
#include<stdio.h>
#include"./headers/debug.h"

/* 
	worked_imperfect_otto_cycle simula un ciclo di otto tra due bagni,
	con temperature ref_temp e ref_temp*temp_ratio.
	Le termalizzazioni sono imperfette e simulate in ipotesi
	di dinamica Markoffiana del sistema lavorante (RAFW) e
	il lavoro viene calcolato mediante integrazione del differenziale
	lavoro.
*/

static void   *hm_;
static double ref_temp_;
static double non_ref_temp_;
static double (*omega_int_)(int k);
static double (*spectral_function_)(double omega);

static void free_F(double tau,double dt)
{
	unitary_F(hm_,tau,dt);
}
static void ref_F(double tau,double dt)
{
	DUP(); free_F(tau,dt);
	SWAP(); dissipative_F(
		hm_,tau,dt,
		omega_int_,
		spectral_function_,ref_temp_,0);
	SUM();
}
static void non_ref_F(double tau,double dt)
{
	DUP(); free_F(tau,dt);
	SWAP(); dissipative_F(
		hm_,tau,dt,
		omega_int_,
		spectral_function_, non_ref_temp_, 0);
	SUM();
}



static void isothermal_transf(
	void *hm,
	void *f,
	double ti,double tf,double dt,
	double *heat,double *work,double previous_energy,double *after_energy)
{
	double w;

	w=plain_evolve_matrix(hm,f,ti,tf,dt);
	(*work)+=w;
	(*after_energy)=energy(hm_,tf);
	(*heat)+=((*after_energy)-previous_energy)-w;
}
static void adiabatic_transf(
	void *hm,
	double ti,double tf,double dt,
	double *work,double *after_energy)
{
	(*work)+=plain_evolve_matrix(hm,free_F,ti,tf,dt);
	(*after_energy)=energy(hm_,tf);
}

void studio_carnot_cycle(
	double ref_temp, double temp_ratio,
	double contact_time, double adiabatic_time, double dt,

	double	(*omega_int)(int k), 
	double	(*spectral_function)(double), 

	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r,
	double *e_cn, double *e_wn, double *e_cr, double *e_wr)
{

	ref_temp_		=	ref_temp;
	non_ref_temp_		=	temp_ratio*ref_temp;

	hm_			=	hm;
	omega_int_		=	omega_int;
	spectral_function_	=	spectral_function;


	make_thermal_state(0,non_ref_temp_,hm);

	(*e_wr)=energy(hm,0);


	int i=4;
	while(i--){
		(*work_n)=0;
		(*heat_n)=0;
		(*work_r)=0;
		(*heat_r)=0;


		isothermal_transf(
			hm,
			non_ref_F,
			0,contact_time,dt,
			heat_n,work_n,(*e_wr),e_cn);
	
		adiabatic_transf(
			hm,
			contact_time,contact_time+adiabatic_time,dt,
			work_n,e_wn);
	

		isothermal_transf(
			hm,
			ref_F,
			contact_time+adiabatic_time,adiabatic_time,dt,
			heat_r,work_r,(*e_wn),e_cr);

		adiabatic_transf(
			hm,
			adiabatic_time,0,dt,
			work_r,e_wr);
	}

	DROP();

}
/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
