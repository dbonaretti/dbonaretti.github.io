#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include"./headers/rafw.h"
#include"./headers/ising.h"
#include"./headers/debug.h"


#define HEATER  	'H'
#define FRIDGE 		'F'
#define EXTRACTOR	'E'
#define ACCELERATOR 	'A'

#define	IMPNS		'~'
#define IMPAS		'~'


int tell_regime(double cold,double hot)
{
	if((hot+cold)>0){
		if(cold>0)
			return IMPAS;
		else
			return EXTRACTOR;
	}
	if(hot>0)
		return ACCELERATOR;
	else if(cold>0)
		return FRIDGE;
	else
		return HEATER;
}

double triple_fmax(double a,double b,double c)
{
	return fmax(a,fmax(b,c));
}
int max(int a,int b)
{
	return a<b ? b : a;
}

double efficiency_ratio(double heat_r, double heat_n, double temp_ratio)
{
	return (1+(heat_n/heat_r))/(1-temp_ratio);
}
void print_stats(
	double ratio,
	double work_n, double heat_n, double work_r, double heat_r)
{
	printf("%0.4lf\t",				work_n+work_r+heat_n+heat_r);
	printf("%0.4lf\t%0.4lf\t%0.4lf\t", 		work_n, work_r, work_n+work_r);
	printf("%0.4lf\t%0.4lf\t%0.4lf\t", 		heat_n, heat_r, heat_n+heat_r);
	printf("%e\t",					(1+(heat_n/heat_r))/(1-ratio));
	
	putchar('\n');
}


double run_carnot_cycle(
	char *regime,

	double ref_temp,
	double ratio,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double thermalization_time,
	double isothermal_time,
	double adiabatic_time,

	int int_steps) /* STARTING_G -- AFTER_CYCLE_G */
{
	double work_r=0; double work_n=0; double heat_r=0; double heat_n=0;

	carnot_cycle(
		ref_temp,
		ref_temp*ratio,
		
		tau_1,tau_2,tau_3,tau_4, /* here */

		thermalization_time, isothermal_time, adiabatic_time,
		fmax(adiabatic_time, isothermal_time )/int_steps,

		ising_omega_interaction, 
		ising_spectral_function, 
		ising_hm,

		&work_n, &heat_n, &work_r, &heat_r
	);

	(*regime)=tell_regime(heat_n,heat_r);
	return efficiency_ratio( heat_r, heat_n,ratio);
}

int randr_counter=1;

double randr( double a, double b)
{
	srand(rand()+randr_counter);
	randr_counter++;
	double f= (rand()%100)/100.0;
	return f*(b-a)+a;
}


void study_regime_state( /* -- regime_state */
	double prec,
	double start_temp, double ref_temp, double ratio,

	double tau_1, double tau_2, double tau_3, double tau_4,
	double term_time, double isothermal_time, double adiabatic_time,

	int int_steps) 
{
	double m;
	int n=0;
	
	char regime;
	char start=1;

	make_thermal_state(tau_1, start_temp, ising_hm );

	while(start || m>prec){
		start=0;

		DUP(); 
		run_carnot_cycle( 
			&regime,
			ref_temp, ratio,
			tau_1, tau_2, tau_3, tau_4,
			term_time, isothermal_time, adiabatic_time,
			int_steps);
		SWAP(); OVER(); /*  -- G_i+1 G_i G_i+1 */

		m=NORM();

		SUB(); 
		m=NORM()/m;

		printf("%d\t%e\n",++n,m);
		DROP();
	}
	DROP();
}


int main()
{
	int k=2;
	int sites = 6;

	InitMemory(2*sites,15);

	double conv_prec	=	1e-8;
	int int_steps		= 	400;
	int sites_num		=	sites;
	
	double tau_1 		=	0.5;
	double tau_2		=	0.75;	  	
	double tau_3		=	1;
	double tau_4		=	0.75;

	double start_temp	= 	7;
	double ref_temp		=	5;
	double ratio		=	0.5;

	double term_time	=	30;
	double iso_time		=	30;
	double adi_time		=	30;

	

	study_regime_state(
		conv_prec,
		start_temp, ref_temp, ratio,
	
		tau_1, tau_2, tau_3, tau_4,
		term_time, iso_time, adi_time,

		int_steps);


	return 0;
}


/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

