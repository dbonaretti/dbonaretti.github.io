#include"headers/rafw.h"
#include"headers/debug.h"


/*	--- GENERAL NOTATION ---

	hm  := address for Hamiltonian matrix generator routine

	tau := time parameter 
	dt  := time integration step
	beta:= inverse temperature 
	temp:= temperature
	mu  := chemical potential
*/


/*--------------------------------------------------
	Y[V] matrix generation
--------------------------------------------------*/

static double DeltaR( double *w, int k)
{
	int n=MatrixDim/2;

	if(k<n)
		return w[k+n]-w[k];
	else
		return w[k-n]-w[k];
}

struct f_args
{ 
	double *w;
	double_complex (*v_function)(double omega);
};
		
static double_complex F_val( int i, int j, void *args)
{
	struct f_args *fa=args;
	if(i==j)	
		return (*fa->v_function)(DeltaR(fa->w,i));
	else
		return 0;
}	

static void load_F( double *w, double_complex (*v_function)(double))
{
	struct f_args fa={w,v_function};
	ARG_FLOAD( F_val, &fa); 
}

static double_complex W_val( int i, int j, void *arg)
{
	int n=MatrixDim/2;
	double (*omega_interazione)(int)=arg;

	if(i>=n || j>=n)
		return 0;
	else
		return   conj((*(omega_interazione))(i))*(*(omega_interazione))(j);
}

static void load_W( double (*omega_interazione)(int))
{
	ARG_FLOAD(W_val,omega_interazione);
}

static void load_L_trans(
	void *hm,
	double tau,
	double *w,
	double (*omega_interazione)(int))	
{
	load_W(omega_interazione);
	LOAD_OMEGA_TILDE(); LOAD_BOG_U(hm,tau,w); MUL(); 
		UcrossAU();
}





static void load_Y_trans(
	void *hm,
	double tau,
	double (*omega_interazione)(int),
	double_complex (*V_function)(double))
{
	double w[ MatrixDim];
	BOG_EIGVALS( hm, tau, w);
	
	LOAD_OMEGA(); LOAD_BOG_U( hm, tau, w); MUL(); 
	load_L_trans( hm, tau, w, omega_interazione); load_F( w, V_function); DMUL();
		UAUcross(); 
}

/*--------------------------------------------------
	Generazione termini evolutivi 
--------------------------------------------------*/

static void Lambs_dG( /* G -- dG */
	void *hm,
	double tau,
	double dt,
	double (*omega_interazione)(int),
	double (*spectral_function)(double omega),
	double temp,
	double mu)
{
	load_Y_trans(
			hm,
			tau,
			omega_interazione,
			S_function( spectral_function, temp, mu)); 

	COMMUTATOR( 2*dt*I); SWAP();
	MINUS_PART(); 
}


static void Diss_dG(
	void *hm,
	double tau,
	double dt,
	double (*omega_interazione)(int),
	double (*spectral_function)(double omega),
	double temp,
	double mu) /* G -- dG */
{
	load_Y_trans(
		hm,
		tau,
		omega_interazione,
		Gamma_function( spectral_function, temp, mu)); 

	ANTI_COMMUTATOR(-2*dt); MINUS_PART(); 
}

void dissipative_F(	/* G -- dG */
	void *hm,
	double tau,
	double dt,

	double (*omega_interaction)(int p),
	double (*spectral_function)(double omega),
	double temp,
	double mu)
{
	/* 
		In the specific case of the Ising chain the Lambs shift terms
		are null, thus it is convenient to avoid their calculation.

		For this reason the Lambs_dG routine is not really tested and should
		be considered unsafe.
	*/
	/*
	DUP(); Lambs_dG(
			hm,
			tau,
			dt,
			omega_interaction,
			spectral_function,
			temp,
			mu); 
	SWAP(); Diss_dG(
			hm,
			tau,
			dt,
			omega_interaction,
			spectral_function,
			temp,
			mu); 
	SUM(); 
	*/

	Diss_dG(
		hm,
		tau,
		dt,
		omega_interaction,
		spectral_function,
		temp,
		mu); 
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

