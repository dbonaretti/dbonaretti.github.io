#include"./headers/rafw.h"
#include<stdio.h>
#include"./headers/debug.h"

/* 
	worked_imperfect_otto_cycle simula un ciclo di otto tra due bagni,
	con temperature ref_temp e ref_temp*temp_ratio.
	Le termalizzazioni sono imperfette e simulate in ipotesi
	di dinamica Markoffiana del sistema lavorante (RAFW) e
	il lavoro viene calcolato mediante integrazione del differenziale
	lavoro.
*/

void carnot_cycle(
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double isothermal_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_b, double *heat_b, double *work_a, double *heat_a)
{
	thermalize(
		temp_b,
		tau_1, term_time, dt,
		omega_int, spectral_function, hm,
		work_b,
		heat_b);
	
	isothermal(
		temp_b,
		tau_1,tau_2,isothermal_time,dt,
		omega_int, spectral_function, hm,
		work_b,
		heat_b);

	adiabatic(
		tau_2,tau_3,adiabatic_time,dt,
		hm, work_b,heat_b);

	thermalize(
		temp_a,
		tau_3, term_time, dt,
		omega_int, spectral_function, hm,
		work_a,
		heat_a);
		
	isothermal(
		temp_a,
		tau_3,tau_4,isothermal_time,dt,
		omega_int, spectral_function, hm,
		work_a,
		heat_a);

	adiabatic(
		tau_4,tau_1,adiabatic_time,dt,
		hm, 
		work_a,
		heat_a);
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
