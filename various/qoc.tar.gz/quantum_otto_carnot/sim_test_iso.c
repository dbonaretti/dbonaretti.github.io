/* 
	Testing the limit properties for the imperfect isothermal and the thermalization 
	The initial state is parameterized by beta_0, the protocol is slowed by a factor alpha.

	The function 

		c( \alpha, \tau) = sup { | \Delta \rho( \alpha, t) | : t>\tau }

	is  considered.
	When the protocol is slowed

		C( \alpha) = c( \alpha, \tau) (\tau -->inf) 

	have to be

		C(0) = 0 

	When the initial state is the proper one we have the isotherm:

		c(\alpha=0, \tau=0 ) = 0 

*/
#include"./headers/rafw.h"
#include"./headers/ising.h"
#include<stdio.h>
#include<stdlib.h>

#define ARB_TAU 1.17
#define TAU_0 0.75
#define TAU_1 0.25


#define DELTA_TIME_0 10
#define INT_STEPS 100 
#define TEMP_BATH 10


double alpha_;
double_complex osc_ising_hm( double tau, int i, int j)
{
	tau = sin(alpha_*tau);
	return ising_hm(TAU_0+tau*TAU_1, i, j);
}


void evolve_g(  double ti, double tf, double dt) /* in state -- out state */
{
	in_contact_evolve( 
		osc_ising_hm, 
		ti, 
		tf, 
		(tf-ti),	
		dt,
		TEMP_BATH,
		
		ising_omega_interaction,
		ising_spectral_function);
}
/* G1 G2 -- */
double normed_distance() 
{
	double h,m;

	m= NORM();
	SUB(); h= NORM();

	DROP();

	return h/m;
}

/*
double normed_distance() 
{
	double h;

	SUB(); h= NORM();
	DROP();
	return h;
}
*/

double distance_from_bath( double tau) /* G_1 -- */
{
	make_thermal_state( tau, TEMP_BATH, osc_ising_hm);
	return normed_distance();
}

void iso_test(double alpha, double temp_ratio, double max_time, int steps, int shots)
{

	double delta_time_0 = max_time/shots;
	double dt = ( delta_time_0*shots)/steps ;
	double ti=0;
	double tf = delta_time_0;

	alpha_ = alpha;

	make_thermal_state( 0, temp_ratio*TEMP_BATH, osc_ising_hm);

	while(shots--){
		DUP(); printf("%e\t%e\n", tf, distance_from_bath( tf));

		evolve_g( ti, tf, dt );

		ti = tf;
		tf += delta_time_0;
	}

	putchar('\n');
	DROP();
}

int main(int argc,char **argv)
{


	int sites=20;

	if(argc!=6){
		printf("usage: [alpha] [init_temp/bath_temp] [max_time] [steps] [shots]\n"); 
		return 1;
	}
	
	InitMemory( sites*2, 15);

	double alpha = atof( argv[1]);
	double ratio = atof( argv[2]);
	double time= atof( argv[3]);
	int steps = atoi( argv[4]);
	int shots = atoi( argv[5]);

	fprintf( stderr, "alpha=%lf\n", alpha);
	fprintf( stderr, "ratio=%lf\n", ratio);
	fprintf( stderr, "max_time=%lf\n", time);
	fprintf( stderr, "steps=%d\n", steps);
	fprintf( stderr, "shots=%d\n", shots);

	iso_test( alpha, ratio, time, steps, shots);

	return 0;
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

