#include"./headers/rafw.h"
#include<stdio.h>
#include"./headers/debug.h"

/* 
	worked_imperfect_otto_cycle simula un ciclo di otto tra due bagni,
	con temperature ref_temp e ref_temp*temp_ratio.
	Le termalizzazioni sono imperfette e simulate in ipotesi
	di dinamica Markoffiana del sistema lavorante (RAFW) e
	il lavoro viene calcolato mediante integrazione del differenziale
	lavoro.
*/

void comp_carnot_cycle(
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double isothermal_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r)
{
	isothermal(
		temp_b,
		tau_1,tau_2,isothermal_time,dt,
		omega_int, spectral_function, hm,
		work_n,
		heat_n);

	adiabatic(
		tau_2,tau_3,adiabatic_time,dt,
		hm, work_n,heat_n);

	isothermal(
		temp_a,
		tau_3,tau_4,isothermal_time,dt,
		omega_int, spectral_function, hm,
		work_r,
		heat_r);

	adiabatic(
		tau_4,tau_1,adiabatic_time,dt,
		hm, 
		work_r,
		heat_r);
}
