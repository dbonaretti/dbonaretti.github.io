#include"./headers/rafw.h"
#include"./headers/debug.h"

double tau_i_;
double tau_f_;
double delta_;

double tau_protocol(double t)
{
	return tau_i_+t*(tau_f_-tau_i_)/delta_;
}
static void rk_inc(
	void (*f)(double tau,double dt),
	double t,
	double dt)
{
	double_complex G[MatrixDim][MatrixDim];

	double tau1	=	tau_protocol(t);
	double tau23	=	tau_protocol(t+dt/2);
	double tau4	=	tau_protocol(t+dt);
	
	STORE(G); (*f)(tau1,dt);				/* K1 */
	DUP(); SCALE(0.5); LOAD(G); SUM();  (*f)(tau23,dt);	/* K2 */
	DUP(); SCALE(0.5); LOAD(G); SUM();  (*f)(tau23,dt);	/* K3 */
	DUP(); LOAD(G); SUM(); (*f)(tau4,dt); 			/* K4 */

	/* -- K1 K2 K3 K4 */

	MROT();

	/* -- K1 K4 K2 K3 */

	SUM(); SCALE(1./3.);
	
	MROT();

	SUM(); SCALE(1./6.);

	SUM();
}



static void heun_inc( /* y -- increment */
	void (*f)(double tau,double dt),
	double t,
	double dt)
{
	double tau1	=	tau_protocol(t);
	double tau2	=	tau_protocol(t+dt);

	DUP(); (*f)(tau1,dt);
	SWAP(); OVER();SUM(); (*f)(tau2,dt); SUM();
	SCALE(0.5);
}

static void simple_inc( /* y -- increment */
	void (*f)(double tau,double dt),
	double t,
	double dt)
{
	double tau	=	tau_protocol(t);
	(*f)(tau,dt);
}

static double work_diff(/* G -- G */
	double_complex (*hm)(double tau,int i,int j),
	double t,
	double dt
	)
{
	if(tau_i_==tau_f_)
		return 0;
	else
		return (energy( hm, tau_protocol(t+dt))-energy( hm, tau_protocol(t-dt)))/2;
}

double evolve_matrix( /* G(ti) -- G(tf) */
	double_complex (*hm)(double tau,int i,int j),
	void (*f)(double tau,double dt),
	double tau_i,
	double tau_f,
	double delta_time,
	double dt
	)
{
	if(delta_time<1e-8 || dt<1e-8)
		return 0;

	tau_i_ = tau_i;
	tau_f_ = tau_f;
	delta_ = cabs(delta_time);

	double work=0;
	int j=0;
	int D;

	dt=cabs(dt);
	D=abs(delta_time/dt);


	while(j<=D){
		DUP(); rk_inc(f, j*dt, dt); SUM();
		work+=work_diff(hm,j*dt,dt);
		j++;
	}
	return work;
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

