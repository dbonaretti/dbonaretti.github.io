#include"./headers/rafw.h"

/* 
	This routine demands an initial correlation matrix 
	and ignores it: it is automatically substituted with a thermal
	matrix corresponding with the temperature of the first bath.
	
	The first adiabatic transformation is made changing the 
	initial parameter tau_1, into tau_3 in a time equal to adiabatic_time.
	The same procedure is repeated thermalizing at the other temperature	
	and making and adiabatic trasformation from tau_3 back to tau_1 with 
	the same timings of the previous one.
	tau_2 and tau_4 are ignored.

	At the end of the procedure the final correlation matrix appears loaded
	on top of the stack.

	The work done during the adiabatic transformations is written at the addresses
	work_b and work_a.
	Similarly is done for the heats exchanged.


*/
/*
	--- PARAMETERS ---

	temp_a  :=	Second bath temperature
	temp_b  :=	First  bath temperature
	
	tau_1	:=	First Hamiltonian control parameter
	tau_3	:=	Second Hamiltonian control parameter
	tau_2	:=	ignored parameter
	tau_4	:=	ignored parameter

	adiabatic_time	:= 	time duration of the adiabatic transformation

	dt :=	integration time-step
	hm := 	Hamiltonian matrix generator routine address

	work_b := 	address for work value during first adiabatic transformation
	work_a := 	address for work value during second adiabatic transformation
	heat_b := 	heat exchanged with the first bath
	heat_a := 	heat exchagend with the second bath
a

	--- IGNORED PARAMTERS ---

	term_time 	
	contact_time 	
	omega_int
	spectral_function
*/






void perfect_otto_cycle( /* START -- END */
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double contact_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)( int k), 
	double (*spectral_function)( double), 
	double_complex (*hm)( double time, int i, int j),

	double *work_b,
	double *heat_b,
	double *work_a,
	double *heat_a)
{
	double e_cb;
	double e_wb;
	double e_ca;
	double e_wa;
		
	DROP();

	make_thermal_state( tau_1, temp_b, hm);			e_cb = energy( hm, tau_1);
	free_evolve( hm, tau_1, tau_3, adiabatic_time, dt);	e_wb = energy( hm, tau_3);

	DROP();

	make_thermal_state( tau_3, temp_a, hm);			e_ca = energy( hm, tau_3);
	free_evolve( hm, tau_3, tau_1, adiabatic_time, dt);	e_wa = energy( hm, tau_1);


	(*work_b)+= e_wb-e_cb;
	(*heat_b)+= e_cb-e_wa;
	(*work_a)+= e_wa-e_ca;	
	(*heat_a)+= e_ca-e_wb;
}


/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
