#include"./headers/test.h"
#include"./headers/ising.h"
#include<stdio.h>

double JCoupling=1;

int main(int argc,char **argv)
{

	if(argc!=6){
		printf("sim_test_therm [sites] [start field] [dt] [precision] [cutoff] --> [argmin time] \n");
		return -1;
	}

	int sites=atoi(argv[1]);
	double start=atof(argv[2]);
	double dt=atof(argv[3]);
	double conv_prec=atof(argv[4]);
	double cutoff=atof(argv[5]);

	InitMemory(sites*2,15);
	
	
	therm_minimum_test(
		ising_hm,
		0,
		ising_omega_interaction,
		ising_spectral_function,
		dt,
		conv_prec,
		cutoff,
		start
	);

	return 0;
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

