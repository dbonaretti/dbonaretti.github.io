
/*
	Qui sono raccolte alcune funzioni matematiche utili tra cui
	il necessario per diagonalizzare e cambiare base.
*/

#include<lapacke.h>
#include<stdlib.h>
#include<stdio.h>
#include<cblas.h>
#include<math.h>

typedef lapack_complex_double double_complex;

#include"./headers/rafw.h"

void simple_zgemm(
	int op1,
	int op2,
	double_complex alpha,
	double_complex beta,
	void *a_mat,
	void *b_mat,
	void *c_mat)
{
	cblas_zgemm(
			CblasRowMajor,op1,op2, 
			MatrixDim, MatrixDim, MatrixDim, 
			&alpha, 
				a_mat,MatrixDim,
				b_mat,MatrixDim, 
			&beta,
				c_mat,MatrixDim);
}


/*--------------------------------------------
	PAIR STACK OPERATIONS 
--------------------------------------------*/

void dmul_op	(double_complex *a, double_complex *b)  { (*a)*=(*b);}
void sum_op	(double_complex *a, double_complex *b)  { (*a)+=(*b);}
void sub_op	(double_complex *a, double_complex *b)  { (*a)-=(*b);}
void conj_op	(double_complex *a, double_complex *b)	{ (*a)=conj(*b);}


void ZGEMM(int op1,int op2,double_complex alpha,double_complex beta) /* A B C -- A B beta*C+AB*alpha */
{
	simple_zgemm(op1,op2,alpha,beta,StackThird(),StackSecond(),StackFirst());
}

void CONJ()	/* A -- A_conj */
{
	forij(conj_op,StackFirst(),StackFirst());
}

void SUM()	/* A B -- A+B */
{
	forij(sum_op,StackSecond(),StackFirst());
	DROP();
}
void DMUL()	/* A B -- A+B */
{
	forij(dmul_op,StackSecond(),StackFirst());
	DROP();
}
void SUB()	/* A B -- A-B */
{
	forij(sub_op,StackSecond(),StackFirst());
	DROP();
}
void MUL() 	/* A B -- A*B */
{
	simple_zgemm(CblasNoTrans,CblasNoTrans,1,0,StackSecond(),StackFirst(),StackSucc());
	swapn(StackIndex,StackIndex-2);
	DROP();
}
void SCALE(double_complex alpha)	/* A -- alpha*A */
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];
	a=StackFirst();

	for(i=0;i<MatrixDim;i++)
		for(j=0;j<MatrixDim;j++)
			(*a)[i][j]*=alpha;
}

void DUP_SCALE( double_complex alpha) /* A -- A alpha*A */
{
	int i,j;
	double_complex (*a)[MatrixDim][MatrixDim];
	double_complex (*b)[MatrixDim][MatrixDim];
	a=StackFirst();
	b=StackSucc();

	for(i=0;i<MatrixDim;i++)
		for(j=0;j<MatrixDim;j++)
			(*b)[i][j]= alpha*(*a)[i][j];
	StackIndex++;
}


void TRANS()	/* A -- A_transposed */
{
	int i,j;
	double_complex tmp;
	double_complex (*m)[MatrixDim][MatrixDim]=StackFirst();

	for(i=0;i<MatrixDim;i++)
		for(j=i;j<MatrixDim;j++){
			tmp=(*m)[j][i];
			(*m)[j][i]=(*m)[i][j];
			(*m)[i][j]=tmp;
		}
}

void CROSS()	/* A -- A_cross */
{
	int i,j;
	double_complex tmp;
	double_complex (*m)[MatrixDim][MatrixDim]=StackFirst();

	for(i=0;i<MatrixDim;i++)
		for(j=i;j<MatrixDim;j++){
			tmp=(*m)[i][j];
			(*m)[i][j]=conj((*m)[j][i]);
			(*m)[j][i]=conj(tmp);
		}
}

void COMMUTATOR(double_complex alpha) /* A B -- alpha*[A,B] */
{
	void *A=StackSecond();;
	void *B=StackFirst();

	simple_zgemm(CblasNoTrans,CblasNoTrans,1,0,B,A,StackSucc());
	simple_zgemm(CblasNoTrans,CblasNoTrans,alpha, -1*alpha,A,B,StackSucc());
	
	swapn(StackIndex-2,StackIndex);
	DROP();
}

void ANTI_COMMUTATOR(double_complex alpha) /* A B -- alpha*[A,B] */
{
	void *A=StackSecond();;
	void *B=StackFirst();

	simple_zgemm(CblasNoTrans,CblasNoTrans,1,0,B,A,StackSucc());
	simple_zgemm(CblasNoTrans,CblasNoTrans,alpha,alpha,A,B,StackSucc());
	
	swapn(StackIndex-2,StackIndex);
	DROP();
}

void UcrossAU() /* A U -- UcrossAU */
{
	void *A=StackSecond();
	void *U=StackFirst();
	void *AU=StackSucc();


	simple_zgemm(CblasNoTrans,CblasNoTrans,1,0,A,U,AU);
	simple_zgemm(CblasConjTrans,CblasNoTrans,1,0,U,AU,StackSuccSucc());

	swapn(StackIndex-1,StackIndex+1);
	SWAP(); DROP();
}

void UAUcross() /* U A -- UAUcross */
{
	void *U=StackSecond();
	void *A=StackFirst();
	void *UA=StackSucc();

	simple_zgemm(CblasNoTrans,CblasNoTrans,1,0,U,A,UA);
	simple_zgemm(CblasNoTrans,CblasConjTrans,1,0,UA,U,StackSuccSucc());

	swapn(StackIndex-1,StackIndex+1);
	SWAP(); DROP();
}


/*-------------------------------------------------
	Diagonalizzazione
--------------------------------------------------*/


void EIGVALS(double *w)	/* A -- */
{
	LAPACKE_zheev_work( 
			LAPACK_ROW_MAJOR, 'N', 'U', 
			MatrixDim, StackFirst(),MatrixDim,
			w,
			StackSucc(),
			MatrixDim*MatrixDim,
			StackSuccSucc()
			);
	DROP();

}



void DIAG(double *w)	/* A -- U */
{
	LAPACKE_zheev_work( 
			LAPACK_ROW_MAJOR, 'V', 'U', 
			MatrixDim, StackFirst(),MatrixDim,
			w,
			StackSucc(),
			MatrixDim*MatrixDim,
			StackSuccSucc()
			);
}


void EIGVECTS()
{
	double w[MatrixDim];
	DIAG(w);
}


/*-------------------------------------------------
	Componenti 'minus'e 'plus' di una matrice V
--------------------------------------------------*/

int dv(int j)
{
	int n=MatrixDim/2;
	return j<n ? j+n : j-n;
}
static double_complex svs(int i,int j)
{
	double_complex (*m)[MatrixDim][MatrixDim]=StackFirst();
	return (*m)[dv(i)][dv(j)];
}
static double_complex minus_part_val(int i,int j)
{
	double_complex (*m)[MatrixDim][MatrixDim]=StackFirst();
	return ((*m)[i][j]-(*m)[dv(j)][dv(i)])/2.0;
}
static double_complex plus_part_val(int i,int j)
{
	double_complex (*m)[MatrixDim][MatrixDim]=StackFirst();
	return ((*m)[dv(j)][dv(i)]+(*m)[i][j])/2.0;
}
void MINUS_PART()  /* V -- V_meno */
{
	FLOAD(minus_part_val);
	NIP();
}
void PLUS_PART()  /* V -- V_plus */
{
	FLOAD(plus_part_val);
	NIP();
}


/*------------------------------------------------
	Matrice identita' 2Nx2N
-------------------------------------------------*/



double_complex id_val(int i,int j)
{
	return i==j ? 1 : 0 ;
}
void LOAD_ID()
{
	FLOAD(id_val);
}


/*------------------------------------------------
	Matrice omega grande  2Nx2N

		( 0  1 )
		( 1  0 ) tensore I
------------------------------------------------*/


double_complex omega_val(int i,int j)
{
	int n=MatrixDim/2;

	if((i+n)==j || (j+n)==i)
		return 1;
	else
		return 0;
}

void LOAD_OMEGA()
{
	FLOAD(omega_val);
}




/*------------------------------------------------
	Matrice Chi
------------------------------------------------*/


double_complex chi_val(int i,int j)
{
	int n=MatrixDim/2;

	if( (i<n && j<n && j==(n-i-1)) || (i>=n && j>=n && i==j) )
		return 1;
	else 
		return 0;
}

void LOAD_CHI()
{
	FLOAD(chi_val);
}


/*------------------------------------------------
	Matrice Sigma Tilde = Sigma + Identity
------------------------------------------------*/


double_complex omega_tilde_val(int i,int j)
{
	return omega_val(i,j)+id_val(i,j);
}

void LOAD_OMEGA_TILDE()
{
	FLOAD(omega_tilde_val);
}


/*------------------------------------------------
	Matrice Sigma L
------------------------------------------------*/




double_complex inv_diag_val(int i,int j)
{
	int n=MatrixDim/2;

	return i==(n-j-1) ? 1.0 : 0.0 ;
}
double_complex omega_l_val(int i,int j)
{
	int n;
	n=MatrixDim/2;

	if(i>=n && j<n)
		return (i-n)==j ? 1 : 0 ;
	if(i<n && j>=n)
		return inv_diag_val(i,j-n);
	else
		return 0;
}
void LOAD_OMEGA_L()
{
	FLOAD(omega_l_val);
}


/*-------------------------------------------------
	Miscellanea
--------------------------------------------------*/


double TRACE() /* A -- A */
{ 
	int k= MatrixDim;
	double (*m)[MatrixDim][MatrixDim];
	double t=0;

	m=StackFirst();
	
	while(k--)
		t+=(*m)[k][k];

	return t;
}


double NORM() /* A -- A */
{
	int i=0;
	int d=MatrixDim*MatrixDim;
	double_complex *m;
	double res=0;

	m=StackFirst();

	while(i<d){
		res+=m[i]*conj(m[i]);
		i++;
	}
	return sqrt(res);
}
void PRINT_NORM() /* A -- A */
{
	printf("NORMA: %e\n",NORM());
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
