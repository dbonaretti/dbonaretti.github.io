#include"./headers/rafw.h"
#include"./headers/ising.h"
#include<stdio.h>


#define TIME_PERC_INCREMENT 0.5

/* 
	worked_imperfect_otto_cycle simula un ciclo di otto tra due bagni,
	con temperature ref_temp e ref_temp*temp_ratio.
	Le termalizzazioni sono imperfette e simulate in ipotesi
	di dinamica Markoffiana del sistema lavorante (RAFW) e
	il lavoro viene calcolato mediante integrazione del differenziale
	lavoro.
*/

double percentile_distance() /* G_0 G_1 -- G_0 G_1 */
{
	double m,r;

	OVER(); r=NORM(); OVER();  SUB(); m=NORM();
	DROP();

	return m/r;
}


void thermalization_test(
	double_complex (*hm)(double tau,int i,int j),
	double bath_temperature,
	double (*omega_interaction)(int k),
	double (*spectral_function)(double omega),
	double fixed_tau,
	double dt,
	double conv_prec,
	double cutoff
	)
{
	double t_old		=	0;
	double ttime_i=1;
	double pd;

	make_thermal_state(fixed_tau,bath_temperature,hm); 
	make_thermal_state(1.17,100,hm); /* -- G_target G_start */
	
	do{
		in_contact_evolve(
			hm,
			fixed_tau, fixed_tau, ttime_i-t_old, dt,
			bath_temperature, omega_interaction, spectral_function);

		t_old=ttime_i;
		ttime_i*=(1+TIME_PERC_INCREMENT);

		pd= percentile_distance();
		printf("%e %e\n", t_old, pd );
	}while( pd>conv_prec && ttime_i<cutoff);


	DROP();
	DROP();
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
