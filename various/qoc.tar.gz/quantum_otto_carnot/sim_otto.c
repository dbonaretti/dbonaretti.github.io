#include"./headers/ising.h"

int main(int argc,char **argv)
{
	ising_sim(argc,argv,perfect_otto_cycle);
	return 0;
}
