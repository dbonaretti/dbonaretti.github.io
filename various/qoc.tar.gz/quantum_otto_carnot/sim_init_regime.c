/*
	Calculating regime features of the mixed cycle


*/
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include"./headers/rafw.h"
#include"./headers/ising.h"
#include"./headers/debug.h"


#define HEATER  	'H'
#define FRIDGE 		'F'
#define EXTRACTOR	'E'
#define ACCELERATOR 	'A'

#define	IMPNS		'~'
#define IMPAS		'~'


double triple_fmax(double a,double b,double c)
{
	return fmax(a,fmax(b,c));
}
int max(int a,int b)
{
	return a<b ? b : a;
}



void run_carnot_cycle(
	double *work_r, double *work_n, double *heat_r, double *heat_n,

	double ref_temp,
	double ratio,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double thermalization_time,
	double isothermal_time,
	double adiabatic_time,

	int int_steps) /* STARTING_G -- AFTER_CYCLE_G */
{

	carnot_cycle(
		ref_temp,
		ref_temp*ratio,
		
		tau_1,tau_2,tau_3,tau_4, /* here */

		thermalization_time, isothermal_time, adiabatic_time,
		fmax(adiabatic_time, isothermal_time )/int_steps,

		ising_omega_interaction, 
		ising_spectral_function, 
		ising_hm,

		work_n, heat_n, work_r, heat_r
	);
}

double CampisiFunction( 
	double temp_r,
	double temp_n,
	double temp_s,
	double work_r,
	double work_n,
	double heat_r,
	double heat_n)
{
	double delta_e = work_r+ work_n+ heat_r+ heat_n;

	return (delta_e/temp_s) - (heat_n/temp_n) - (heat_r/temp_r);
}

double make_regime_state( /* -- regime_state */
	double prec,
	double start_temp, double ref_temp, double ratio,

	double tau_1, double tau_2, double tau_3, double tau_4,
	double term_time, double isothermal_time, double adiabatic_time,

	int int_steps) /* STARTING_G -- AFTER_CYCLE_G */
{
	double m;
	
	char regime;
	char start=1;


	double work_r = 0;
	double work_n = 0;
	double heat_r = 0;
	double heat_n = 0;

	make_thermal_state(tau_1, start_temp, ising_hm );

	while(start || m>prec){
		start=0;

		DUP(); 
		run_carnot_cycle( 
			&work_r, &work_n, &heat_r, &heat_n,
			ref_temp, ratio,
			tau_1, tau_2, tau_3, tau_4,
			term_time, isothermal_time, adiabatic_time,
			int_steps);
		SWAP(); OVER(); /*  -- G_i+1 G_i G_i+1 */


		SUB(); 
		m=NORM();
		DROP();
	}

	return CampisiFunction(
		ref_temp,
		ratio*ref_temp,
		start_temp,
		work_r,
		work_n,
		heat_r,
		heat_n);
}

double perc( int n, int m, double a, double b)
{
	double p = n;
	p/=m;
	return (a-b)*p+b;
}


void test_pars_shot( int sites, int steps)
{
	double conv_prec	=	1e-8;
	int int_steps		= 	steps;
	int sites_num		=	sites;
	
	double tau_1 		=	0.5;
	double tau_2		=	0.75;	 /* dh_2 = +0.25 */
	double tau_3		=	1;
	double tau_4		=	0.75;	/* dh_5 = -0.25 */

	double start_temp	= 	7;
	double ref_temp		=	5;
	double ratio		=	0.5;

	double term_time	=	30;
	double iso_time		=	30;
	double adi_time		=	30;


	double alpha_0, alpha_1, alpha_2, alpha_3;
	double *v[] = { &alpha_0, &alpha_1, &alpha_2, &alpha_3};
	double norm;

	double campisi_value_1;
	double campisi_value_2;


	int k = 0;
	int n = 15;
	double rt1, rt2;


	rt1 = perc( 0, n, 0.01, 1000);
	campisi_value_1 = make_regime_state(	
		conv_prec, 
		rt1, ref_temp, ratio,
		tau_1, tau_2, tau_3, tau_4,
		term_time, iso_time, adi_time,	
		int_steps); 

	while(k<n){
		k++;

		rt2 = perc( k, n, 0.01, 1000);
		campisi_value_2 = make_regime_state(	
			conv_prec, 
			rt2, ref_temp, ratio,
			tau_1, tau_2, tau_3, tau_4,
			term_time*(1+alpha_1), iso_time*(1+alpha_2), adi_time*(1+alpha_3),	
			int_steps);

		SWAP(); OVER();

		SUB();  
	
		printf("%lf\t%lf\t%lf\t%lf\t%e\n",
			rt1,
			rt2,
			campisi_value_1,
			campisi_value_2,
			NORM()); DROP();
		campisi_value_1 = campisi_value_2;
		rt1= rt2;
	}
	DROP();
}


int main( int argc, char **argv)
{
	int sites, steps;

	if(argc!=3){
		printf("[sites] [steps]\n");
		return -1;
	}
	
	sites = atoi( argv[1]);
	steps = atoi( argv[2]);
	
	fprintf( stderr,"%d\n%d\n%d\n", sites, steps);

	InitMemory(2*sites,15);

	test_pars_shot( sites, steps);

	return 0;
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
