#include"./headers/rafw.h"
#include<stdio.h>
#include"./headers/debug.h"

/* 
	worked_imperfect_otto_cycle simula un ciclo di otto tra due bagni,
	con temperature temp_a e temp_b.
	Le termalizzazioni sono imperfette e simulate in ipotesi
	di dinamica Markoffiana del sistema lavorante (RAFW) e
	il lavoro viene calcolato mediante integrazione del differenziale
	lavoro.
*/

void worked_imperfect_otto_cycle( /* START -- END */
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double contact_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r)
{
	DROP();
	make_thermal_state(tau_1,temp_b,hm);
	adiabatic(
		tau_1,
		tau_3,
		adiabatic_time,
		dt,
		hm,
		work_n,heat_n);

	thermalize(
		temp_a,
		tau_3, term_time,dt,
		omega_int, spectral_function,hm,work_r,heat_r); 				
	adiabatic(
		tau_3,
		tau_1,
		adiabatic_time,
		dt,
		hm,
		work_r,heat_r);

	thermalize(
		temp_b,
		tau_1, term_time,dt,
		omega_int, spectral_function,hm,work_n,heat_n); 				
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
