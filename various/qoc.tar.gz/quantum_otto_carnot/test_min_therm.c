#include"./headers/rafw.h"
#include"./headers/test.h"
#include<stdio.h>
#include"./headers/debug.h"


/* bindings for the thermalization_time(field) function  */

struct test_args
{
	double_complex (*hm)(double tau,int i,int j);
	double bath_temperature;
	double (*omega_interaction)(int k);
	double (*spectral_function)(double omega);
	double dt;
	double conv_prec;
	double cutoff;
};


double to_minimize(double tau,void *args)
{
	struct test_args *a=args;
	double out_t_old;
	double out_ttime_i;
	double out_e_current;
	double out_e_f;
	
	thermalization_test_calc(
		&out_t_old,
		&out_ttime_i,
		&out_e_current,
		&out_e_f,
		a->hm, a->bath_temperature, a->omega_interaction, a->spectral_function,
		tau,
		a->dt, a->conv_prec, a->cutoff);

	return out_t_old;
}

void therm_minimum_test(
	double_complex (*hm)(double tau,int i,int j),
	double bath_temperature,
	double (*omega_interaction)(int k),
	double (*spectral_function)(double omega),
	double dt,
	double conv_prec,
	double cutoff,
	
	double start
	)
{
	struct test_args args={ 
		hm,
		bath_temperature,
		omega_interaction,
		spectral_function,
		0.05,
		conv_prec,
		cutoff};

	start=steepest_descent(start,dt,to_minimize,&args);
	printf("%lf %lf\n",conv_prec,start);
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
