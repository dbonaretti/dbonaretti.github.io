#include<stdio.h>
#include<math.h>
#include"./headers/rafw.h"
#include"./headers/ising.h"
#include"./headers/debug.h"

int Rounds;
int SitesNum;
int IntSteps;

double BaseField;
double DeltaField;
double JCoupling;

double RefTemp;
double FieldStep;
double Ratio;

double TermTime;
double AdiabaticTime;
double IsothermalTime;


#define HEATER  	'H'
#define FRIDGE 		'F'
#define EXTRACTOR	'E'
#define ACCELERATOR 	'A'

#define	IMPNS		'~'
#define IMPAS		'~'


int tell_regime( double cold, double hot)
{
	if((hot+cold)>0){
		if(cold>0)
			return IMPAS;
		else
			return EXTRACTOR;
	}
	if(hot>0)
		return ACCELERATOR;
	else if(cold>0)
		return FRIDGE;
	else
		return HEATER;
}

void print_stats(
	int rounds,
	double ratio,
	double work_n,
	double heat_n,
	double work_r,
	double heat_r)
{
	printf("%d\t",					rounds);
	printf("%0.4lf\t\t",				work_n+work_r+heat_n+heat_r);
	printf("%0.4lf\t%0.4lf\t%0.4lf\t", 		work_n, work_r, work_n+work_r);
	printf("%0.4lf\t%0.4lf\t%0.4lf\t", 		heat_n, heat_r, heat_n+heat_r);
	printf("%e\t",					(1+(heat_n/heat_r))/(1-ratio));
	printf("%c\t",					tell_regime(heat_n,heat_r));
	
	putchar('\n');
}

void run_a_round(
	ThermoCycle *cycle,
	double *work_n,
	double *heat_n,
	double *work_r,
	double *heat_r) /* -- END */
{
	(*cycle)(
		RefTemp,
		RefTemp*Ratio,
		
		BaseField+0,BaseField+DeltaField/2,BaseField+DeltaField,BaseField+DeltaField/2, /* here */

		TermTime,IsothermalTime,AdiabaticTime,fmax(fmax(AdiabaticTime,IsothermalTime),TermTime)/IntSteps,

		ising_omega_interaction, 
		ising_spectral_function, 
		ising_hm,

		work_n, heat_n, work_r, heat_r
	);
}

int max(int a,int b)
{
	return a<b ? b : a;
}
void run_cycle( ThermoCycle *cycle)
{
	double work_r=0,heat_r=0,work_n=0,heat_n=0;
	
	int i=0;
	int d=max( 1, Rounds);
	int b=1;

	make_thermal_state( BaseField, (1+Ratio)*RefTemp/2.0, ising_hm);
	while(i<d){
		i++;

		work_r=0;
		work_n=0;
		heat_r=0;
		heat_n=0;

		run_a_round( cycle, &work_n, &heat_n, &work_r, &heat_r);
		print_stats( i , Ratio, work_n, heat_n, work_r, heat_r);
	}
	DROP();

}

void say_title()
{
	fprintf(stderr,"Round\t");
	fprintf(stderr,"DE_{tot}\tW_C\tW_H\tW_{tot}\tQ_C\tQ_H\tQ_{tot}\t");
	fprintf(stderr,"eta/eta_C\tRegime\n\n");

}

void read_outer_settings(
	int argc,
	char **argv,
	int *rounds,
	int *int_steps,
	int *sites_num,
	double *base_field,
	double *delta_field,
	double *ref_temp,
	double *ratio,
	double *term_time,
	double *isothermal_time,
	double *adiabatic_time)
{
	if(argc!=11){
		printf("Submitted %d/10 arguments!\n",argc-1);
		fprintf(stderr,"sim\n\t[rounds]\n\t[integration steps]\n\t[sites]\n\t[base field]\n\t[delta field]\n\t[reference temperature]\n\t[ratio]\n\t[static thermalization time]\n\t[isothermal time]\n\t[adiabatic time]\n\n");
		exit(1);
	}
		
   	sscanf(argv[1], "%d", rounds);
   	sscanf(argv[2], "%d", int_steps);
	sscanf(argv[3], "%d",  sites_num);
	sscanf(argv[4], "%lf", base_field);
	sscanf(argv[5], "%lf", delta_field);
	sscanf(argv[6],	"%lf",  ref_temp);
	sscanf(argv[7], "%lf", ratio);
	sscanf(argv[8], "%lf", term_time);
	sscanf(argv[9], "%lf", isothermal_time);
	sscanf(argv[10],"%lf",  adiabatic_time);

   	fprintf(stderr, "Rounds ----------: %d\n", *rounds);
   	fprintf(stderr, "Integration steps: %d\n", *int_steps);
	fprintf(stderr, "Sites number ----: %d\n", *sites_num);
	fprintf(stderr, "Base field ------: %lf\n",*base_field);
	fprintf(stderr, "Delta field -----: %lf\n",*delta_field);
	fprintf(stderr, "Reference temp --: %lf\n",*ref_temp);
	fprintf(stderr, "Temperature ratio: %lf\n",*ratio);
	fprintf(stderr, "Therm time ------: %lf\n",*term_time);
	fprintf(stderr, "Isothermal time -: %lf\n",*isothermal_time);
	fprintf(stderr, "Adiabatic time---: %lf\n\n",*adiabatic_time);
}

void ising_sim(int argc,char **argv,ThermoCycle *cycle)
{
	read_outer_settings(argc,argv,
		&Rounds,
		&IntSteps,
		&SitesNum,
		&BaseField,
		&DeltaField,
		&RefTemp,
		&Ratio,
		&TermTime,
		&IsothermalTime,
		&AdiabaticTime);
	
	InitMemory(2*SitesNum,15);
	

	say_title();
	run_cycle(cycle);
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
