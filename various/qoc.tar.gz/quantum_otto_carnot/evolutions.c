#include"headers/rafw.h"



static void   *hm_;
static void free_F( double tau, double dt) /* G -- dG */
{
	HLOAD( hm_, tau); MINUS_PART(); SWAP(); COMMUTATOR( I*dt);
	MINUS_PART();
}

static double temperature_;
static double (*omega_int_)(int k);
static double (*spectral_function_)(double omega);

static double temperature_b;
static double (*omega_int_b)(int k);
static double (*spectral_function_b)(double omega);


/* 	
	Liouville step operator for a function system
	in contact with a heat bath.
*/


static void in_contact_F(double tau,double dt)
{
	DUP();  free_F( tau, dt);
	SWAP(); dissipative_F(
		hm_, tau, dt,
		omega_int_,
		spectral_function_ , temperature_, 0);
	SUM();
}


/* 	
	Liouville step operator for a function system
	in contact with two heat baths at the same time.
*/

static void double_contact_F( double tau, double dt)
{
	DUP(); free_F(tau,dt);

	OVER(); dissipative_F(
			hm_, tau, dt,
			omega_int_b,
			spectral_function_b, temperature_b, 0); SUM();
	SWAP(); dissipative_F(
			hm_, tau, dt,
			omega_int_b,
			spectral_function_b, temperature_b, 0); SUM();
}

/*
	Evolves the correlation matrix as if the working substance
	is interacting with no heat bath.
*/


double free_evolve(
	double_complex (*hm)(double tau,int i,int j),
	double tau_i,
	double tau_f,
	double delta_time,
	double dt)
{
	hm_			=	hm;
	return evolve_matrix(hm,free_F,tau_i,tau_f,delta_time,dt);
}


/*
	Evolves the correlation matrix as if the working substance
	is in contact with a heat bath. 
*/


double in_contact_evolve(
	double_complex (*hm)(double tau,int i,int j),
	double tau_i,
	double tau_f,
	double delta_time,
	double dt,

	double temperature,
	double (*omega_int)(int k),
	double (*spectral_function)(double omega))
{
	hm_			=	hm;
	temperature_		=	temperature;
	omega_int_		=	omega_int;
	spectral_function_	=	spectral_function;
	
	return evolve_matrix(hm,in_contact_F,tau_i,tau_f,delta_time,dt);
}


/*
	Evolves the correlation matrix as if the working substance 
	is in contact with two heat baths at the same time.

	This routine has not been tested, but it seems quite safe.
*/

double double_contact_evolve(
	double_complex (*hm)(double tau,int i,int j),
	double tau_i,
	double tau_f,
	double delta_time,
	double dt,

	double temperature_1,
	double (*omega_int_1)(int k),
	double (*spectral_function_1)(double omega),

	double temperature_2,
	double (*omega_int_2)(int k),
	double (*spectral_function_2)(double omega))
{
	hm_			=	hm;

	temperature_		=	temperature_1;
	omega_int_		=	omega_int_1;
	spectral_function_	=	spectral_function_1;
	
	temperature_b		=	temperature_2;
	omega_int_b		=	omega_int_2;
	spectral_function_b	=	spectral_function_2;

	return evolve_matrix(hm,double_contact_F,tau_i,tau_f,delta_time,dt);
}


/*
	
*/


void thermalize(
	double temperature,
	double tau, double term_time, double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat)
{
	double e_before;
	e_before = energy(hm,tau);
	in_contact_evolve( hm, tau, tau, term_time,dt, temperature, omega_int, spectral_function);
	(*heat)+=(energy(hm,tau)-e_before);
}

void isothermal(
	double temperature,

	double tau_i,
	double tau_f,

	double iso_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat)
{
	double w_inc;
	double e_before;
	double e_after;

	e_before = energy(hm,tau_i);
	w_inc = in_contact_evolve(
			hm,
			tau_i,
			tau_f,
			iso_time,
			dt,temperature,
			omega_int,
			spectral_function);

	e_after = energy(hm,tau_f);

	(*heat)+= e_after-e_before-w_inc;
	(*work)+= w_inc;
}

void adiabatic(
	double tau_i,
	double tau_f,

	double adiabatic_time,
	double dt,

	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat)
{
	(*work)+=free_evolve(hm, tau_i, tau_f, adiabatic_time, dt);
}

void double_isothermal(
	double temperature_1,
	double temperature_2,

	double tau_i,
	double tau_f,

	double iso_time,
	double dt,

	double (*omega_int_1)(int k), 
	double (*spectral_function_1)(double), 

	double (*omega_int_2)(int k), 
	double (*spectral_function_2)(double), 

	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat)
{
	double w_inc;
	double e_before;
	double e_after;

	e_before = energy(hm,tau_i);
	w_inc = double_contact_evolve(
			hm, tau_i, tau_f, iso_time, dt,
			temperature_1, omega_int_1, spectral_function_1,
			temperature_2, omega_int_2, spectral_function_2);
	e_after = energy(hm,tau_f);

	(*heat)+= e_after-e_before-w_inc;
	(*work)+= w_inc;
}
