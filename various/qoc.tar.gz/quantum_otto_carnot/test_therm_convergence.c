#include"./headers/rafw.h"
#include"./headers/ising.h"
#include<stdio.h>
#include"./headers/debug.h"


double mod_coeff_;

double modulated_spectral_function( double omega)
{
	return ising_spectral_function( omega)*mod_coeff_;
}
void make_diagonal_form( double tau) /* G -- DIAG_G */
{
	double w[MatrixDim];
	LOAD_BOG_U( ising_hm, tau, w);
	UcrossAU();
}

double get_bog_g( int i, int j, double tau) /* G(tau) -- G(tau) */
{
	double_complex (*m)[MatrixDim][MatrixDim];  
	double w[MatrixDim];
	double_complex c;

	DUP(); make_diagonal_form( tau);
	m=StackFirst();

	c=(*m)[i][j];

	DROP();

	return cabs(c);
}

void print_fraction(double time, double c)
{
	printf("%e %e\n", time,  log(c) );
}

double percentile_distance() /* G_0 G_1 -- */
{
	double m,r;

	OVER(); r=NORM(); OVER();  SUB(); m=NORM();
	DROP();

	return m/r;
}


void thermalization_cons_test(
	int i,
	int j,
	double bath_temperature,
	double fixed_tau,
	double total_time,
	double shot_time,
	double dt,
	double mod_coeff
	)
{
	double t=0;
	double c_0;
	mod_coeff_ = mod_coeff;

	make_thermal_state( 1.17, 0.5*bath_temperature , ising_hm);  /* -- G */
	
	while(t<total_time){
		in_contact_evolve(
			ising_hm,
			fixed_tau, fixed_tau, shot_time, dt,
			bath_temperature, ising_omega_interaction, modulated_spectral_function);
		t += shot_time;

		print_fraction( t, get_bog_g( i, j, fixed_tau) ); 
	}

	make_diagonal_form( fixed_tau);
	PRINT_MATRIX();
	
	DROP();

}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

