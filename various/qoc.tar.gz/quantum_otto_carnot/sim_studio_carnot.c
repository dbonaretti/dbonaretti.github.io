#include"./headers/ising.h"

int main(int argc,char **argv)
{
	ising_sim(argc,argv,studio_carnot_cycle);
	return 0;
}
