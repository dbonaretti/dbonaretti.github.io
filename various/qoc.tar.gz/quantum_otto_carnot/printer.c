#include<stdio.h>
#include"./headers/rafw.h"

void just_print_complex(double_complex c)
{
	fprintf( stderr, "(%0.3lf,%0.3lf)",creal(c),cimag(c));
}



double module(double_complex c)
{
	double r,i;

	r=creal(c);
	i=cimag(c);

	return sqrt(r*r+i*i);

}
void print_complex(double_complex c)
{
	if(creal(c)==0 && cimag(c)==0)
		fprintf( stderr, "     0     \t");
	else if(module(c)<0.0000001)
		fprintf( stderr, "    ~0     \t");
	else
		fprintf( stderr, "(%0.3lf,%0.3lf)",creal(c),cimag(c));
}
int min(int a,int b)
{
	return a<b? a : b ;
}
void print_matrix(void *mat,int dim)
{
	double_complex (*m)[dim][dim]=mat;
	int i,j;
	int row_dim=min(dim,8);
	int col_dim=min(dim,8);

	putchar('\n');
	for(i=0;i<col_dim;i++){
		for(j=0;j<row_dim;j++){
			print_complex((*m)[i][j]);
		}
		fputc( '\n', stderr);
	}
	fputc( '\n', stderr);
			
}


/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

