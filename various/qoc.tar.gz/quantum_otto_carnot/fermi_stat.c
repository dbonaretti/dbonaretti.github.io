#include<complex.h>
#include<stdlib.h>
#include<cblas.h>
#include<math.h>
#include"./headers/debug.h"
#include"./headers/rafw.h"


/*
	La funzione make_thermal_state carica in cima allo stack delle
	matrici la matrice di correlazione calcolata con ensemble canonico
	a temperatura temp desiderata.

	make_ground_state serve invece se occorre forzare la temperatura 
	piu' fredda possibile di modo da ottenere la matrice di correlazione
	del ground state. La matrice risultante e' caricata in cima allo stack.
*/



double fermi(double temp,double e)
{
	if(temp<1e-20)
		temp=1e-20;

	return 1.0/(exp(e/temp)+1.0);
}


void make_b(double *w,double temp) /* -- <BBcross> */
{
	int i,n;

	n=MatrixDim/2;
	double_complex (*m)[MatrixDim][MatrixDim];
	double a;


	LOAD_ID();
	m=StackFirst();

	i=0;
	while(i<n){
		a=fermi(temp,w[i+n]-w[i]); 

		(*m)[i][i]=1-a; 
		(*m)[n+i][n+i]=a;

		i++;
	}
}

void make_thermal_state( /* -- <AAcross> */
	double time,
	double temp,
	double_complex (*hm)(double time,int i,int j))
{
	double w[MatrixDim];

	LOAD_BOG_U(hm,time,w);
	make_b(w,temp); 
		UAUcross();
}

double energy(double_complex (*hm)(double tau,int i,int j),double tau)
{
	int i,j;
	double_complex (*m)[MatrixDim][MatrixDim]=StackFirst();
	double res=0;

	for(i=0; i<MatrixDim; i++)
		for(j=0; j<MatrixDim; j++){
			res+= ((*hm)(tau,j,i)*(*m)[i][j]);
		}
	
	return res;
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

