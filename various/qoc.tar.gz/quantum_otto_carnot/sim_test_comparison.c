/*
	Comparison between Otto and Carnot cycles through the mixed cycle
*/

#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include"./headers/rafw.h"
#include"./headers/ising.h"
#include"./headers/debug.h"


#define HEATER  	'H'
#define FRIDGE 		'F'
#define EXTRACTOR	'E'
#define ACCELERATOR 	'A'

#define	IMPNS		'~'
#define IMPAS		'~'


int tell_regime(double cold,double hot)
{
	if((hot+cold)>0){
		if(cold>0)
			return IMPAS;
		else
			return EXTRACTOR;
	}
	if(hot>0)
		return ACCELERATOR;
	else if(cold>0)
		return FRIDGE;
	else
		return HEATER;
}

double triple_fmax(double a,double b,double c)
{
	return fmax(a,fmax(b,c));
}
int max(int a,int b)
{
	return a<b ? b : a;
}

double efficiency_ratio(double hot_heat, double cold_heat, double temp_ratio)
{
	if(temp_ratio>1)
		temp_ratio=1.0/temp_ratio;

	return (1+(cold_heat/hot_heat))/(1-temp_ratio);
}
void print_stats(
	double ratio,
	double work_n, double heat_n, double work_r, double heat_r)
{
	printf("%0.4lf\t",				work_n+work_r+heat_n+heat_r);
	printf("%0.4lf\t%0.4lf\t%0.4lf\t", 		work_n, work_r, work_n+work_r);
	printf("%0.4lf\t%0.4lf\t%0.4lf\t", 		heat_n, heat_r, heat_n+heat_r);
	printf("%e\t",					(1+(heat_n/heat_r))/(1-ratio));
	
	putchar('\n');
}


double CampisiFunction( 
	double temp_r,
	double temp_n,
	double temp_s,
	double work_r,
	double work_n,
	double heat_r,
	double heat_n)
{
	double delta_e = work_r+ work_n+ heat_r+ heat_n;

	return (delta_e/temp_s) - (heat_n/temp_n) - (heat_r/temp_r);
}


double run_carnot_cycle(
	char *regime,

	double *work_r,
	double *work_n,
	double *heat_r,
	double *heat_n,

	double ref_temp,
	double ratio,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double thermalization_time,
	double isothermal_time,
	double adiabatic_time,

	int int_steps) /* STARTING_G -- AFTER_CYCLE_G */
{
	double work_n_inc=0;
	double heat_n_inc=0;
	double work_r_inc=0;
	double heat_r_inc=0;

	carnot_cycle(
		ref_temp,
		ref_temp*ratio,
		
		tau_1,tau_2,tau_3,tau_4, /* here */

		thermalization_time, isothermal_time, adiabatic_time,
		fmax(adiabatic_time,isothermal_time)/int_steps,

		ising_omega_interaction, 
		ising_spectral_function, 
		ising_hm,

		&work_n_inc, &heat_n_inc, &work_r_inc, &heat_r_inc
	);

	(*work_n)+= work_n_inc;
	(*heat_n)+= heat_n_inc;
	(*work_r)+= work_r_inc;
	(*heat_r)+= heat_r_inc;

	(*regime)=tell_regime( heat_n_inc, heat_r_inc);

	return efficiency_ratio( heat_r_inc, heat_n_inc, ratio);
}


double perc_dist( ) /* G_1 G_2 -- */
{
	double m;
	m = NORM();
	SUB(); m = NORM()/m;
	DROP();
	
	return m;
}


void print_short_value( double v)
{
	printf("%0.3lf\t",v);
}
void print_value(double v)
{
	printf("%lf\t",v);
}
void print_regime(char regime)
{
	printf("%c\t",regime);
}

void run_until_convergence(
	double ref_temp,
	double ratio,

	double tau_1, double tau_2, double tau_3, double tau_4,
	double term_time, double isothermal_time, double adiabatic_time,

	int int_steps) /* STARTING_G -- AFTER_CYCLE_G */
{

	double work_r=0;
	double work_n=0;
	double heat_r=0;
	double heat_n=0;


	double current_work_r;
	double current_work_n;
	double current_heat_r;
	double current_heat_n;

	double dist;
	double eta_curr;

	char regime;
	double campisi_value;

	make_thermal_state( tau_1, (1+ratio)*ref_temp/2.0, ising_hm);

	do{
		DUP();
		current_work_r = 0;
		current_work_n = 0;
		current_heat_r = 0;
		current_heat_n = 0;

		eta_curr=run_carnot_cycle( 
			&regime,
			&current_work_r,
			&current_work_n,
			&current_heat_r,
			&current_heat_n,

			ref_temp, ratio,
			tau_1, tau_2, tau_3, tau_4,
			term_time,isothermal_time, adiabatic_time,
			int_steps);
		SWAP(); OVER(); /* -- new_G old_G new_G */

		work_r += current_work_r;
		work_n += current_work_n;
		heat_r += current_heat_r;
		heat_n += current_heat_n;
		
	}while( perc_dist() > 1e-8 );
	DROP();

	campisi_value = CampisiFunction( 
				ref_temp,
				ref_temp*ratio,
				(1+ratio)*ref_temp/2.0,
				work_r,
				work_n,
				heat_r,
				heat_n);

	print_regime( regime);

	print_value( current_work_r);
	print_value( current_work_n);
	print_value( current_heat_r);
	print_value( current_heat_n);

	print_value( eta_curr);
	print_value( campisi_value);
	putchar('\n');
}



double perc(double a,double b,int n,int d)
{
	double f;
	f=((double) n) /((double) d);
	return (b*n)/d+((d-n)*a)/d;
}




void otto_carnot_test( 
	double sign,
	int int_steps,
	int sites_num,
	double term_time,
	double iso_time,
	double adi_time)
{
	double tau_1 		=	0.5;
	double tau_2		=	0.5;	  	
	double tau_3		=	1;
	double tau_4		=	1;

	double ref_temp		=	5;
	double ratio		=	0.5;


	InitMemory( 2*sites_num, 15);
	double campisi_value;


	int t=25;
	int k=0;
	char regime;

	double delta_h;
	double eta;
	
	while(k<=t){
		delta_h	= perc( -0.25, 0.25, k++, t);

		print_value(delta_h);
		run_until_convergence(	
			ref_temp, ratio,
			tau_1, tau_2+delta_h, tau_3, tau_4+(delta_h*sign),
			term_time, iso_time, adi_time,	
			int_steps);
	}
}


int main( int argc, char **argv)
{
	int sites;
	int int_steps;
	double term_time;
	double iso_time;
	double adi_time;
	double sign_4;

	if( argc!=7 ){
		printf( "[modifier=-1? 1=yes] [int_steps] [sites] [term_time] [iso_time] [adi_time]\n");
		return -1;
	}

	sign_4 = ( atoi( argv[1] ) == 1 ? -1 : 1 );
	int_steps = atoi( argv[2] );
	sites = atoi( argv[3] );
	term_time = atof( argv[4] );
	iso_time = atof( argv[5] );
	adi_time = atof( argv[6] );

	fprintf( stderr, "modifier: %lf\n", sign_4);
	fprintf( stderr, "int_steps: %d\n", int_steps);
	fprintf( stderr, "sites: %d\n", sites);
	fprintf( stderr, "term_time: %lf\n", term_time);
	fprintf( stderr, "iso_time: %lf\n", iso_time);
	fprintf( stderr, "adi_time: %lf\n", adi_time);

	fprintf( stderr, "delta_h\t\tregime\thot_work\tcold_work\thot_heat\tcold_heat\teta\t\tcampisi\n");

	otto_carnot_test(
		sign_4,
		int_steps,
		sites,
		term_time,
		iso_time,
		adi_time);
	return 0;
}


/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

