
/*----------------------------------------------------

	Generatore di matrice H per 
	operatore quadratico di catena 1-D Ising con
	campo trasverso

----------------------------------------------------*/

#include"./headers/rafw.h"
#include"./headers/debug.h"
#include<stdio.h> 

#define JCoupling 1

double ising_spectral_function(double epsilon) 
{ 
	if(epsilon>=0)
		return 1.0; 
	return 0;
} 
double ising_omega_interaction(int k) 
{ 
	return 1;
}

static double_complex M(double tau,int i,int j)
{
	if(i==j)
		return -tau;
	return 0;
}
static double_complex N(double tau,int i,int j)
{
	if(i==(j+1))
		return -JCoupling;
	return 0;
}
static double_complex O(double tau,int i,int j)
{
	return N(tau,j,i);
}
static double_complex R(double tau,int i,int j)
{
	if(abs(i-j)==1)
		return -JCoupling;
	if(i==j)
		return tau;
	return 0;
}

double_complex ising_hm( double tau, int i, int j)
{
	int n=MatrixDim/2;


	if(i<n && j<n)
		return M(tau,i,j);
	if(i<n && j>=n)
		return N(tau,i,j-n);
	if(i>=n && j<n)
		return O(tau,i-n,j);

	return R(tau,i-n,j-n);
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

