#include"./headers/rafw.h"
#include<stdio.h>
#include"./headers/debug.h"

/* 
	The first adiabatic transformation is made changing the 
	initial parameter tau_1, into tau_3 in a time equal to adiabatic_time.
	The same procedure is repeated thermalizing at the other temperature	
	and making and adiabatic trasformation from tau_3 back to tau_1 with 
	the same timings of the previous one.
	tau_2 and tau_4 are ignored.

	At the end of the procedure the final correlation matrix appears loaded
	on top of the stack.

	The work done during the adiabatic transformations is written at the addresses
	work_n and work_r.
	Similarly is done for the heats exchanged.


*/
/*
	--- PARAMETERS ---

	temp_a  :=	Second bath temperature
	temp_b  :=	First  bath temperature
	
	tau_1	:=	First Hamiltonian control parameter
	tau_3	:=	Second Hamiltonian control parameter
	tau_2	:=	ignored parameter
	tau_4	:=	ignored parameter

	adi_time	:= 	time duration of the adiabatic transformation

	dt :=	integration time-step
	hm := 	Hamiltonian matrix generator routine address

	work_b := 	address for work value during first adiabatic transformation
	work_a := 	address for work value during second adiabatic transformation
	heat_b := 	heat exchanged with the first bath
	heat_a := 	heat exchagend with the second bath
a

	the_time := 	thermalization time
	omega_int :=		address for omega function
	spectral_function := 	address for spectral function

	--- IGNORED PARAMTERS ---
	
	iso_time


*/


void imperfect_otto_cycle( /* START -- END */
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double the_time,
	double iso_time,
	double adi_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	double *work_b,
	double *heat_b,
	double *work_a,
	double *heat_a)
{
	double e_cb;
	double e_wb;
	double e_ca;
	double e_wa;

	in_contact_evolve(
		hm,
		tau_1,tau_1,
		the_time,dt,

		temp_b,
		omega_int,
		spectral_function); 			e_cb=energy(hm,tau_1);

	free_evolve( hm,tau_1,tau_3,adi_time, dt); 	e_wb=energy(hm,tau_3);
	in_contact_evolve(
		hm,
		tau_3,tau_3, 
		the_time, dt,
		
		temp_a,
		omega_int,
		spectral_function); 			e_ca=energy(hm,tau_3);
	free_evolve( hm,tau_3,tau_1, adi_time, dt);	e_wa=energy(hm,tau_1);

	(*work_b)+= e_wb-e_cb;
	(*heat_b)+= e_cb-e_wa;
	(*work_a)+= e_wa-e_ca;	
	(*heat_a)+= e_ca-e_wb;
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

