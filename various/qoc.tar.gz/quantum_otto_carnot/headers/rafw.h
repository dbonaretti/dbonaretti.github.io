
#ifndef RAFW_H
#define RAFW_H

#include<lapacke.h>
#include<cblas.h>
#include<math.h>
	
#define TRUE 1
#define FALSE 0

typedef lapack_complex_double double_complex;

extern void **StackArray;
extern void *EigenvectorsCache;
extern void *EigenvaluesCache;


double GetMatrixDim(); /* MatrixDim non dovrebbe essere modificato, pero' per adesso ci accontentiamo */
double GetStackDim();
void InitMemory(int matrix_dim,int stack_dim);
void die(char *msg);
int check(int x);
int check_cache(int x);



extern int MatrixDim;

/* from richardson.c */

double richardson(
	double (*f)( double t),
	double h,
	double T,
	int order);


/* from stack.c */

extern int StackIndex;




void STORE(void *mat);
void ARG_FLOAD(double_complex (*mm)(int i,int j,void *args),void *args);	/* -- A */
void FLOAD(double_complex (*mm)(int i,int j));	/* -- A */
void PERT_HLOAD(double_complex (*hm)(double time,int i,int j),double time); /* -- H(t) */
void HLOAD(double_complex (*hm)(double time,int i,int j),double time); /* -- H(t) */
void THLOAD(double_complex (*hm)(double time,int i,int j),double time); /* -- H(t) */
void RANDOM_HERMITIAN();

void LOAD(void *mat);	/* -- A */
void TLOAD(void *mat);	/* -- A_trans */
  
void CACHE_STORE(int n);
void CACHE_LOAD(int n);


void DUP();		/* A -- A A */
void OVER();		/* A B -- A B A */
void PRINT_MATRIX(); 	/* A -- A */

void *StackFirst();
void *StackSecond();
void *StackThird();
void *StackSucc();
void *StackSuccSucc();

void forij(
	void (*op)(double_complex *,double_complex *),
	void *A,
	void *B);

double DROP();
void swapn(int a,int b);
void ROT();
void MROT();
void SWAP();
void NIP();
void SWAP_ZF();
void SWAP_ZS();

/* From algebra.c */

void MINUS_PART();
void PLUS_PART();
double NORM(); /* A -- A */
void PRINT_NORM(); /* A -- A */
void CONJ();			/* A -- A_conj */
void SUM();			/* A B -- A+B */
void DMUL();			/* A B -- A**B */
void SUB();			/* A B -- A-B */
void MUL(); 			/* A B -- A*B */
void SCALE(double_complex alpha);/* A -- alpha*A */
void DUP_SCALE(double_complex alpha);/* A -- A alpha*A */
void TRANS();			/* A -- A_transposed */
void CROSS();			/* A -- A_cross */
void COMMUTATOR(double_complex alpha); /* A B -- alpha*[A,B] */
void ANTI_COMMUTATOR(double_complex alpha); /* A B -- alpha*{A,B} */

void UcrossAU(); 		/* A U -- UcrossAU */
void UAUcross(); 		/* U A -- UAUcross */

void DIAG(double *w);		/* A -- U */
void BOG_DIAG(double *w); 	/* H -- U consistent with Bogoliubov*/
void BOG_FORM(); 		/* H -- H_bog */
void EIGVECTS();		/* A -- U */
void EIGVALS(double *w);	/* A -- */

void LOAD_ID();			/* -- ID_matrix */
void LOAD_T_MATRIX();		/* -- T_matrix */
void LOAD_CHI();		/* -- CHI_matrix */
void LOAD_OMEGA_TILDE();	/* -- OMEGA_TILDE_matrix */
void LOAD_OMEGA();		/* -- OMEGA_matrix */
void LOAD_OMEGA_L();		/* -- OMEGA_L_matrix */

void SMALL_RAND_HE();		/* -- very small random hermitean matrix */
double TRACE(); /* A -- A */


/* from fermi_bogoliubov.c */

void ResetCache();
void LOAD_BOG_U(void *hm,double tau,double *w);
void BOG_EIGVALS(void *hm,double tau,double *w);
void BOG_EIGVECTS(void *hm,double tau);

/* from fermi_stat.c */

double energy(double_complex (*hm)(double tau,int i,int j),double tau);

void make_ground_state( /* -- <AAcross>_ground */
	double time,
	double_complex (*hm)(double time,int i,int j));

void make_thermal_state( /* -- <AAcross> */
	double time,
	double temp,
	double_complex (*hm)(double time,int i,int j));

void make_diag_thermal_state( /* -- <BBcross> */
	double time,
	double temp,
	double_complex (*hm)(double time,int i,int j));

/* from evolutions.c */

double free_evolve(
	double_complex (*hm)(double tau,int i,int j),
	double tau_i,
	double tau_f,
	double delta_time,
	double dt);

double in_contact_evolve(
	double_complex (*hm)(double tau,int i,int j),
	double tau_i,
	double tau_f,
	double delta_time,
	double dt,

	double temperature,
	double (*omega_int)(int k),
	double (*spectral_function)(double omega));

void thermalize(
	double temperature,
	double tau, double term_time, double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat);

void double_isothermal(
	double temperature_1,
	double temperature_2,

	double tau_i,
	double tau_f,

	double iso_time,
	double dt,

	double (*omega_int_1)(int k), 
	double (*spectral_function_1)(double), 

	double (*omega_int_2)(int k), 
	double (*spectral_function_2)(double), 

	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat);


void isothermal(
	double temperature,

	double tau_i,
	double tau_f,

	double iso_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat);

void adiabatic(
	double tau_i,
	double tau_f,

	double adiabatic_time,
	double dt,

	double_complex (*hm)(double time,int i,int j),
	
	double *work, double *heat);


/* from integrator.c */

double evolve_matrix(
	double_complex (*hm)(double tau,int i,int j),
	void (*f)(double time,double dt),
	double tau_i,
	double tau_f,
	double delta_time,
	double dt);

/* from printer.c */

void print_matrix(void *mat,int dim);

/* from linblad_spectre.c */

void *Gamma_function(
	double (*spectral_function)(double omega),
	double temp,
	double mu);

void *S_function(
	double (*spectral_function)(double omega),
	double temp,
	double mu);


/* from dissipator.c */


void dissipative_F(	/* G -- dG */
	void *hm,
	double tau,
	double dt,
	double (*omega_interaction)(int p),

	double (*bath_spectral_function)(double omega),
	double beta,
	double mu);

#endif
