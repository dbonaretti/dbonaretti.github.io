#include<complex.h>

double steepest_descent(
	double start,
	double dt,
	double (*f)(double ,void *),
	void *args);

double convex_descent(
	double start,
	double dt,
	double (*f)(double ,void *),
	void *args);

int thermalization_test_calc(
	double *out_t_old,
	double *out_ttime_i,
	double *out_e_current,
	double *out_e_f,

	double complex (*hm)(double tau,int i,int j),
	double bath_temperature,
	double (*omega_interaction)(int k),
	double (*spectral_function)(double omega),
	double fixed_tau,
	double dt,
	double conv_prec,
	double cutoff
	);

void thermalization_test(
	double complex (*hm)(double tau,int i,int j),
	double bath_temperature,
	double (*omega_interaction)(int k),
	double (*spectral_function)(double omega),

	double fixed_tau,
	double dt,
	double conv_prec,
	double cutoff
	
);

void therm_minimum_test(
	double complex (*hm)(double tau,int i,int j),
	double bath_temperature,
	double (*omega_interaction)(int k),
	double (*spectral_function)(double omega),
	double dt,
	double conv_prec,
	double cutoff,
	
	double start
	);
