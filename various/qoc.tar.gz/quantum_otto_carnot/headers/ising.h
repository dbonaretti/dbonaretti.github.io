#include"rafw.h"
#include"otto_driver.h"

double_complex ising_hm(double time,int i,int j);
double_complex ising_base_field_hm(double tau,int i,int j);

double ising_energy(void *ggc,double lambda);
double ising_work_function(void *ggc,double lambda);
double ising_spectral_function(double epsilon);
double ising_omega_interaction(int k);


void ising_sim(int argc,char **argv,ThermoCycle *cycle);
