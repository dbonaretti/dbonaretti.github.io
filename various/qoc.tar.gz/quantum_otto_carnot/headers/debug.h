#include<stdio.h>
#define flag(x)  printf("flag %s\n",#x)
#define see(x)  printf("look %lf\n",x)
