void perfect_otto_cycle(
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double contact_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r
);


void imperfect_otto_cycle(
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double contact_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r
);


void worked_imperfect_otto_cycle(
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double contact_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r
);

void carnot_cycle(
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double contact_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r
);



typedef void ThermoCycle(
	double temp_a,
	double temp_b,

	double tau_1,
	double tau_2,
	double tau_3,
	double tau_4,

	double term_time,
	double contact_time,
	double adiabatic_time,
	double dt,

	double (*omega_int)(int k), 
	double (*spectral_function)(double), 
	double_complex (*hm)(double time,int i,int j),
	
	double *work_n, double *heat_n, double *work_r, double *heat_r
);

