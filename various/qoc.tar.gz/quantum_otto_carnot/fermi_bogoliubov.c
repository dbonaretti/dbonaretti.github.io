#include<complex.h>
#include<stdlib.h>
#include<cblas.h>
#include<math.h>
#include"./headers/debug.h"
#include"./headers/rafw.h"

/* -------------------------------------------------------------------
	
	Routines for fermionic Bogoliubov-Valatin diagonalization 

----------------------------------------------------------------------*/

/*		
	THETA-K MATRIX MAKING
*/

char is_almost_zero(double g)
{
	return cabs(g)<1e-9;
}

double complex proj_val(int i,int j,void *args)  /* U -- U */
{
	double complex (*u)[MatrixDim][MatrixDim]=StackFirst();
	double complex r=0;
	double *ev=args;
	
	int k=0;
	
	while(k<MatrixDim){
		if(is_almost_zero(ev[k]))
			r+=(*u)[i][k]*conj((*u)[j][k]);
		k++;
	}

	return r;
}

void make_theta_k(double *w) /* U -- U Theta_k*/
{
	ARG_FLOAD(proj_val,w); 
	RANDOM_HERMITIAN(); MINUS_PART();  UAUcross();
}

/*-----------------------------------------
	CORRECTION VIA THETA-K
------------------------------------------*/

void copy_col(void *dest_mat,int dest_col,void *target_mat,int target_col)
{
	int i=MatrixDim; 
	double complex (*d)[MatrixDim][MatrixDim]=dest_mat;
	double complex (*t)[MatrixDim][MatrixDim]=target_mat;

	while(i--)
		(*d)[i][dest_col]=(*t)[i][target_col];
}

int next_zero(int k,double *w)
{
	while(k<MatrixDim)
		if(is_almost_zero(w[k])){
			return k;
		}else
			k++;
	return k;
}
int next_not_zero(int k,double *w)
{
	while(k<MatrixDim)
		if(!is_almost_zero(w[k])){
			return k;
		}else
			k++;
	return k;
}


int kernel_dim(double *w)
{
	int j=0;
	int n=MatrixDim/2;

	while(j<n && !is_almost_zero(w[j]))
		j++;

	return MatrixDim-2*j;
}

void subst_k_in_u(double *w) /* U -- U_corrected */
{
	double theta_w[MatrixDim];
	int kdim;
	
	kdim=kernel_dim(w);
	if(kdim==0)
		return;
	
	LOAD_ID();
	do{
		DROP();
		make_theta_k(w); DIAG(theta_w);  /* U -- U V */ 
	}while((MatrixDim-kernel_dim(theta_w))!=kdim); 

	int k=0;
	int r=0;
	

	while(r<MatrixDim){
		k=next_zero(k,w);
		r=next_not_zero(r,theta_w);
		copy_col(StackSecond(),k,StackFirst(),r);
		k++;
		r++;
	}
	DROP();
}

void J_ope(double *w) 
{
	int i,j; 
	int n=MatrixDim/2;
	double complex (*m)[MatrixDim][MatrixDim]=StackFirst();

	for(j=0; j<n; j++){
		for(i=0; i<n; i++){
			(*m)[i][j+n]=conj((*m)[i+n][j]);
			(*m)[i+n][j+n]=conj((*m)[i][j]);
		}
		w[j+n]=-w[j];
	}
}

void load_bog_u(void *hm,double tau,double *w)
{
	HLOAD(hm,tau); MINUS_PART();
	DIAG(w); subst_k_in_u(w);  J_ope(w);
}


/*-----------------------------------------
	CACHE
------------------------------------------*/

void copy_array(double *target,double *dest)
{
	int j=MatrixDim;
	while(j--)
		dest[j]=target[j];
}

static char init=TRUE;
static double last_tau=0;
static void *last_hm=NULL;

void ResetCache()
{
	init=TRUE;
	last_tau=0;
	last_hm=NULL;
}

void LOAD_BOG_U( void *hm, double tau, double *w)
{

	if(init || tau!=last_tau || hm!=last_hm){
		last_tau=tau;
		last_hm=hm;
		init=FALSE;
		load_bog_u( hm, tau, w); STORE( EigenvectorsCache);
		copy_array( w, EigenvaluesCache);
	}else{
		LOAD( EigenvectorsCache);
		copy_array( EigenvaluesCache,w);
	}
}

void BOG_EIGVALS( void *hm, double tau, double *w)
{
	LOAD_BOG_U(hm,tau,w); DROP();
}
void BOG_EIGVECTS( void *hm, double tau)
{
	double w[MatrixDim];
	LOAD_BOG_U(hm,tau,w);
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

