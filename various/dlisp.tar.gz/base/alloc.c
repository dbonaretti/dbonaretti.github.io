
#include<stdlib.h>
#include "./lisp.h"

struct pair NilAtom	=	{ .car = &NilAtom, .cdr = &NilAtom, .kind = NIL };
struct pair TrueAtom	=	{ .car = &NilAtom, .cdr = &NilAtom, .kind = TRUE };

struct pair *Stack	=	Nil;
struct pair *Data 	=	Nil;
struct pair *User 	=	Nil;

struct pair *D_REG = Nil;

static struct pair Pool[POOLSIZE];

static struct pair *head = Nil;
static unsigned int inited = 0;
static unsigned int allocated = 0;


/* --- Pool allocator with gc --- */

static void mark_and_sweep();

void check()
{
	if( allocated == POOLSIZE ) {
		mark_and_sweep();
		if( allocated == POOLSIZE)
			exit(1);
	}
}
struct pair *alloc_pair()
{
	struct pair *m;

	check();
	if( inited > allocated ){
		m = head;
		head = head ->cdr;
	} else
		m = &Pool[inited++];

	m->mark = UNMARKED;
	allocated++;

	return m;
}

struct pair *init_alloc( 
	struct pair *car,
	struct pair *cdr,
	char kind)
{
	struct pair *m;

	m = alloc_pair();
	m ->car = car;
	m ->cdr = cdr;
	m ->kind = kind;

	return m;
}
	
void dpush_atom( void *car, void *cdr, char kind)
{
	D_REG = init_alloc( car, cdr, kind);
	gen_push( D_REG, &Data);
}

struct pair *alloc_cons(
	struct pair *car,
	struct pair *cdr
	)
{
	return init_alloc( car, cdr, CONS);
}

void gen_push( struct pair *a, struct pair **stack)
{
	(*stack) = alloc_cons( a, (*stack));
}

void free_pair( struct pair *p)
{
	p->cdr = head;
	head = p;
	allocated--;
}

struct pair *gen_pop( struct pair **stack)
{
	struct pair *a, *b;
	a = (*stack);
	b = a->car;
	(*stack) = (*stack)->cdr;
	free_pair( a);
	return b;
}



/* ---	Iterative stop-the-world Mark-Sweep garbage collector --- */


static char in_pool_range( struct pair *p)
{
	return (unsigned int)(p-Pool) < ((unsigned int)inited)*sizeof( struct pair);
}
static char is_aligned( struct pair *p)
{
	return (unsigned int)(p-Pool) % sizeof(void *) == 0;
}
static char valid( void *p)
{
	return 	in_pool_range( p) &&  is_aligned( p);
}

static void single_mark( unsigned int *marked, struct pair *p)
{
	if( valid( p) && p->mark == UNMARKED){
		p->mark = MARKED;
		(*marked)++;
	}
}
static void mark( unsigned int *marked, struct pair *p)
{
	if( is_not_atomic(p)){
		single_mark( marked, p->car);
		single_mark( marked, p->cdr);
	}
	single_mark( marked, p);
}
static unsigned int mark_run()
{
	unsigned int marked = 0;
	unsigned int i = 0;

	while( i<POOLSIZE)
		mark( &marked, &Pool[i++]);

	return marked;
}
static void iterative_mark()
{
	while( mark_run());
}

static void judge( struct pair *p)
{
	if( p->mark ==UNMARKED)
		free_pair( p);
	else 
		p->mark = UNMARKED;
}
static void sweep()
{
	unsigned int i = 0;

	while( i<POOLSIZE)
		judge( &Pool[i++]);
}

static void mark_and_sweep()
{
	unsigned int dummy;
	mark( &dummy, Data);
	mark( &dummy, Stack);
	mark( &dummy, User);
	mark( &dummy, D_REG);
	iterative_mark();
	sweep();
}


/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
