#include<stdio.h>
#include"lisp.h"

#define BUFFSIZE 29

char *open_string	=	"(";
char *close_string	=	")";
char *quote_string	=	"'";
char  word_buffer[ BUFFSIZE];

enum { OPEN, CLOSE,  QUOTE, LETTER, WHITE };

static char current_key = WHITE;

char letterp( char m)
{
	return 	m > ' ' && m != '\'' && m != '(' && m != ')' ;
}
static char group()
{
	if( current_key == '(' )
		return OPEN;
	else if( current_key == ')')
		return CLOSE;
	else if( current_key == '\'')
		return QUOTE;
	else if( letterp( current_key))
		return LETTER;
	else
		return WHITE;
}
static void key()
{
	current_key = fgetc( stdin);
}
static void clean_buffer()
{
	int k = BUFFSIZE; 
	while( k--)
		word_buffer[k] = 0;
}
static void fill_buffer()
{
	int k=0;
	clean_buffer();
	while( group() == LETTER ){
		word_buffer[ k % BUFFSIZE] = current_key;
		key();
		k++;
	}
	word_buffer[BUFFSIZE-1] =0;
}
static void white_ignore()
{
	while( group() == WHITE )
		key();
}

char *nextw_core()
{
	switch( group()){
	case OPEN: 	key();		return open_string;
	case CLOSE: 	key();		return close_string;
	case LETTER: 	fill_buffer(); 	return word_buffer;
	case WHITE: 	white_ignore(); return nextw_core();
	case QUOTE:	key();		return quote_string;
	}
}

char *nextw()
{
	return nextw_core();
}

extern char compile_core_word( char *);
extern void compile_user_word( char *);
extern char compile_number( char *);
extern int  nesting;

void compile_word( char *s)
{
	if( compile_number( s) && compile_core_word( s))
		compile_user_word( s);
}
void compile_sexpr()
{
	int m = nesting;

	nesting = 0;
	do{
		compile_word( nextw());
	}while( nesting != 0);
	nesting = m;
}

void read_sexpr() /* -- sexpr */
{
	current_key =0;
	compile_sexpr();

}


/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
