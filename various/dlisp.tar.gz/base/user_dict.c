#include"lisp.h"
#include<stdlib.h>
#include<stdio.h>
/* -----------------	USER DICTIONARY   -------------------
*/

void load_string( char *string) /* -- num_list */
{
	if( (*string) != 0){
		push_num( *string); 
		load_string( string+1);
		cons();
	}else{
		nil();
	}
		
}
extern void couple();
static void make_voice( char *string)	{ load_string( string); couple(); }	/* atom -- ( atom num_list )*/
static void push_voice( char *string)   /* atom -- */
{
	make_voice( string);
	gen_push( dpop(), &User);
}

static struct pair *pick_atom( struct pair *v)		{ return v->car; }
static struct pair *pick_string( struct pair *v)	{ return v->cdr->car; }

char num_cmp( struct pair *m, int n )
{
	if( m == Nil)
		return n == 0;
	return ( n == ref_num_value(m) );
}

char string_cmp(
	char *string,
	struct pair *l )
{
	while( num_cmp( l->car, (*string) )){
		if(  (*string) == 0 )
			return 1;
		string++;
		l = l->cdr;
	}
	return 0;
}

struct pair *user_look_name( char *string)
{
	struct pair *u = User;
	
	while( u != Nil){
		if( string_cmp( string , pick_string( u->car)))
			return pick_atom( u->car);
		u = u->cdr;
	}
	return Nil;
}

struct pair *user_look_atom( struct pair *a)
{
	struct pair *u = User;
	
	while( u != Nil){
		if( a == pick_atom( u->car))
			return pick_string(u->car);
		u = u->cdr;
	}
	return Nil;
}

void compile_user_word( char *string)
{
	struct pair *v = user_look_name( string);

	if( v!= Nil ){
		load_atom( v);
	}else{
		dpush_atom( Nil, Nil, SYMBOL);
		push_voice( string);
		load_atom( pick_atom( User->car));
	}
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
