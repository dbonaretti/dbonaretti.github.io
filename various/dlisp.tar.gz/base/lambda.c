#include"./lisp.h"

/*
	--- closure ---
		
	( symbol value )

	--- lambda ---

	(  code closures ) 

	clos := ( clo_1 ... clo_n )
*/

extern void print_sexpr_f( struct pair *p);

#define ref_clo_sym( x) 	((x)->car)
#define ref_clo_value( x) 	((x)->cdr->car)

#define ref_la_data( la)	((la)->car)

#define ref_la_code( la)	( ref_la_data(la)->car)
#define ref_la_clos( la)	( ref_la_data(la)->cdr->car)

#define ref_clo_sym_value( x)	ref_sym_value( ref_clo_sym( x))


struct pair *last_lambda = Nil;

void couple()		{	dpush( Nil); cons(); cons();	}	/* a b -- ( a b ) */
void sym_clo() 		{	dup(); value(); couple();	}	/* sym -- clo */

void make_clos();
void first_sym_clo()	{ 	car(); sym_clo(); 		}	/* syms -- clo */
void make_next_clos()	{	cdr(); make_clos();		}	/* syms -- clos */

void make_clos()	/* argl -- clos */
{
	
	if( First != Nil){
		dup(); first_sym_clo(); swap();
		make_next_clos();
		cons();
	}else{
		drop();
		dpush( ref_la_clos( last_lambda));
	}
}


void fexpr_lambda() /* ( code argl -- la )*/
{
	
	make_clos(); 
	couple();
	dpush_atom(  First, Nil, LAMBDA); 
	nip(); 
}

void prim_la_clos() /* la */
{
	if( First->kind == LAMBDA )
		dpush( ref_la_clos( First));
	else
		nil();
	nip();
}
void prim_la_code()
{
	if( First->kind == LAMBDA )
		dpush( ref_la_code( First));
	else
		nil();
	nip();
}


void apply_val_clo(struct pair *val, struct pair *clo) 
{
	struct pair *p;
	

	if( val == Nil)
		p = ref_clo_value( clo);
	else
		p = val;
	
	ref_clo_sym_value( clo) =   p;
}

void save_clo( struct pair *clo)	{  push( ref_clo_sym_value( clo)); }
void update_clo( struct pair *clo)	{  ref_clo_value( clo) 	= ref_clo_sym_value(  clo); }
void restore_clo( struct pair *clo)	{  ref_clo_sym_value( clo) = pop(); }

void closing_eval(
	struct pair *vals,	
	struct pair *clos,
	struct pair *code)
{
	if( clos != Nil ){
		save_clo( clos->car);
		apply_val_clo( vals->car, clos->car);
		closing_eval(  vals->cdr, clos->cdr, code);
		update_clo( clos->car); 
		restore_clo( clos->car);
	}else{
		dpush( code); eval(); 
	}
}


void apply_lambda()	/* ( val_1 ... val_n ) la -- la.(args) */
{
	push( last_lambda);
	last_lambda = First; 

	closing_eval( Second,  ref_la_clos( First), ref_la_code( First) );

	last_lambda = pop();

	nip(); nip();
}

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/

