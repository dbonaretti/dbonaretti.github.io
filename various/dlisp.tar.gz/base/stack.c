#include"./lisp.h"
#include<stdio.h>

void push( struct pair *a)	{ gen_push( a, &Stack); }
void dpush( struct pair *a) 	{ gen_push( a, &Data); }

struct pair * pop()		{ return gen_pop( &Stack); }
struct pair * dpop() 		{ return gen_pop( &Data); }

void rpush()	{	push( dpop()); }
void rpop()	{	dpush( pop()); }
void rcpy()	{	push( First); }

void save()	{	push( Data); Data = Nil;}
void restore()	{	Data = pop(); }


void drop() 	{ 	Data = Data->cdr; }
void cdr()	{	First = First->cdr; }
void car()	{ 	First = First->car; }
void value()	{ 	car(); }
void second_cdr()	{	Second = Second->cdr; }
void second_car()	{ 	Second = Second->car; }
void dup()	{	dpush( First); }
void cons()	{	Second = alloc_cons( Second, First); drop(); }

void nil()	{	dpush( Nil); }
void true()	{	dpush( True); }

void over() 	{ 	dpush( Second); }
void swap()	{ 	struct pair *tmp; tmp = First; First = Second; Second = tmp; }
void scons()	{ 	swap(); cons(); }

void nip()	{ 	Second = First; drop(); }

void push_num( int n)	{ dpush_atom( (void *)n, Nil, INTEGER ); }

void equal()		{ if( First == Second) true(); else nil(); }


void prim_equal()	{ equal(); }

int pop_num()
{
	struct pair *p = dpop();
	if( p->kind == INTEGER )
		return ref_num_value( p);
	else
		return 0;
}


/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
