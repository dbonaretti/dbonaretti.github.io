#include<stdlib.h>
#include<stdio.h>
#include"./lisp.h"

#define ATOM_FOR( f ) 	lisp_##f
#define DEC_ATOM( f, k)  extern void f(); struct pair ATOM_FOR(f) = { .car = (void *)(f), .cdr = Nil, .kind = k }

DEC_ATOM( prim_eq,	PRIM	);
DEC_ATOM( prim_add,	PRIM	);
DEC_ATOM( prim_sub,	PRIM	);
DEC_ATOM( prim_xor,	PRIM	);
DEC_ATOM( prim_div,	PRIM	);
DEC_ATOM( prim_mul,	PRIM	);
DEC_ATOM( prim_cons,	PRIM	);
DEC_ATOM( prim_car,	PRIM	);
DEC_ATOM( prim_cdr,	PRIM	);
DEC_ATOM( prim_list,	PRIM	);
DEC_ATOM( prim_max,	PRIM	);
DEC_ATOM( prim_min,	PRIM	);
DEC_ATOM( prim_apply,	PRIM	);
DEC_ATOM( prim_eval,	PRIM	);
DEC_ATOM( prim_set,	PRIM	);
DEC_ATOM( prim_get,	PRIM	);
DEC_ATOM( prim_setprop,	PRIM	);
DEC_ATOM( prim_revert,	PRIM	);
DEC_ATOM( prim_mapcar,	PRIM	);
DEC_ATOM( prim_equal,	PRIM	);
DEC_ATOM( prim_print,	PRIM	);
DEC_ATOM( prim_la_clos,	PRIM	);
DEC_ATOM( prim_la_code,	PRIM	);
DEC_ATOM( fexpr_lambda,	FEXPR	);
DEC_ATOM( fexpr_defun,	FEXPR	);
DEC_ATOM( fexpr_quote,	FEXPR	);
DEC_ATOM( fexpr_progn,	FEXPR	);
DEC_ATOM( fexpr_cond,	FEXPR	);
DEC_ATOM( fexpr_if,	FEXPR	);


struct voice 
{
	char *name;
	struct pair *atom;
	void (*compile_action)( struct pair *);
};

extern struct voice core_dictionary[];

void close_list( struct pair *p);
void open_list( struct pair *p);
void end( struct pair *p);
void load_atom( struct pair *p);
void quote_short( struct pair *p);

struct voice core_dictionary[] = {
	{	")",		Nil,			close_list	},
	{	"(",		Nil,			open_list	},
	{	"end",		Nil,			end		},
	{	"T",		True,			load_atom	},
	{	"True",		True,			load_atom	},
	{	"true",		True,			load_atom	},
	{	"nil",		Nil,			load_atom	},
	{	"Nil",		Nil,			load_atom	},
	{	"'",		Nil, 			quote_short	},
	{ 	"apply", 	&ATOM_FOR(prim_apply),	load_atom	},
	{ 	"eval", 	&ATOM_FOR(prim_eval),	load_atom	},
	{	"list",		&ATOM_FOR(prim_list),	load_atom	},
	{	"=",		&ATOM_FOR(prim_eq),	load_atom	},
	{	"+",		&ATOM_FOR(prim_add),	load_atom	},
	{	"-",		&ATOM_FOR(prim_sub),	load_atom	},
	{	"xor",  	&ATOM_FOR(prim_xor),	load_atom	},
	{	"/",		&ATOM_FOR(prim_div),	load_atom	},
	{	"*",		&ATOM_FOR(prim_mul),	load_atom	},
	{ 	"cons", 	&ATOM_FOR(prim_cons),	load_atom	},
	{ 	"car", 		&ATOM_FOR(prim_car),	load_atom	},
	{ 	"cdr", 		&ATOM_FOR(prim_cdr),	load_atom	},
	{ 	"set", 		&ATOM_FOR(prim_set),	load_atom	},
	{	"lambda",	&ATOM_FOR(fexpr_lambda),load_atom	},
	{	"defun",	&ATOM_FOR(fexpr_defun),	load_atom	},
	{ 	"quote", 	&ATOM_FOR(fexpr_quote),	load_atom	},
	{ 	"max", 		&ATOM_FOR(prim_max),	load_atom	},
	{ 	"min", 		&ATOM_FOR(prim_min),	load_atom	},
	{ 	"setprop", 	&ATOM_FOR(prim_setprop),load_atom	},
	{ 	"get", 		&ATOM_FOR(prim_get),	load_atom	},
	{ 	"revert", 	&ATOM_FOR(prim_revert),	load_atom	},
	{ 	"lacode", 	&ATOM_FOR(prim_la_code),	load_atom	},
	{ 	"laclos", 	&ATOM_FOR(prim_la_clos),	load_atom	},
	{ 	"if", 		&ATOM_FOR(fexpr_if),	load_atom	},
	{ 	"cond", 	&ATOM_FOR(fexpr_cond),	load_atom	},
	{ 	"progn", 	&ATOM_FOR(fexpr_progn),	load_atom	},
	{ 	"mapcar", 	&ATOM_FOR(prim_mapcar),	load_atom	},
	{ 	"equal", 	&ATOM_FOR(prim_equal),	load_atom	},
	{ 	"print", 	&ATOM_FOR(prim_print),	load_atom	},
/*
	{ 	"gensym", 	&ATOM_FOR(prim_gensym),	load_atom	},
	{ 	"mapcar", 	&ATOM_FOR(prim_mapcar),	load_atom	},
	{ 	"mapcan", 	&ATOM_FOR(prim_mapcan),	load_atom	},
*/
};

extern void compile_sexpr();
extern void push_num( int n);

unsigned int nesting = 0;

void tail( struct pair *p)
{
	struct pair **m = &Data;

	while( (*m) != Nil )
		m = &(**m).cdr;

	(*m) = init_alloc( p, Nil, CONS);
}

void open_list( struct pair *p) 	{ nesting++; push( Data); Data = Nil; }
void close_list( struct pair *p) 	{ nesting--; p = Data; Data = pop(); tail( p);   }
void load_atom( struct pair *p) 	{ tail( p); }

void quote_short( struct pair *p)
{
	open_list( Nil);
	tail(&ATOM_FOR(fexpr_quote));
	compile_sexpr();
	close_list( Nil);
}

void end( struct pair *p)				{ exit(0); }



#define DIC_DIM	(sizeof(core_dictionary)/sizeof(struct voice))

static char cmp( char *a, char *b)
{
	while( (*a)==(*b)){
		if( (*a) == 0)
			return 1;
		a++;
		b++;
	}
	return 0;
}

struct voice *core_look( char *str)
{
	int k;
	for( k =0; k< DIC_DIM; k++)
		if( cmp( str, core_dictionary[ k].name))
			return &core_dictionary[ k];
	return NULL;
}
char *core_look_atom( struct pair *atom)
{
	int k;
	for( k =0; k< DIC_DIM; k++)
		if( atom == core_dictionary[ k].atom )
			return core_dictionary[ k].name;
	return NULL;
}


char numeralp( char c)
{
	return c>='0' && c<='9';
}
char numberp( char *s)
{
	while( *s  !=  0 ){
		if( !numeralp( *s))
			return 0;
		s++;
	}
	return 1;
}


char compile_number( char *string)
{
	int p;
	struct pair *m;
	if( numberp( string) ){
		sscanf( string,"%d", &p);
		push_num( p); m =First; rpush();
		tail(m); pop();
		return 0;
	}
	return 1;
}

char compile_core_word( char *str)
{
	struct voice *v;
	void (*f)();
	v = core_look( str);

	if( v == NULL)
		return 1;

	f = v->compile_action ;
	(*f)( v->atom);

	return 0;
}
/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
