struct pair
{
	struct pair *car;
	struct pair *cdr;
	char kind;
	char mark;
};

#define flag(x) 	printf("FLAG: %s\n", #x)


#define POOLSIZE  4096

#define Nil (&NilAtom)
#define True (&TrueAtom)

#define UNMARKED 0
#define MARKED 1

#define NIL	0
#define TRUE	1
#define CONS    2
#define SYMBOL  3
#define LAMBDA  4

#define is_not_atomic( p) 	((p)->kind <= LAMBDA)

#define INTEGER 6
#define PRIM	7
#define FEXPR	8

#define First	(Data->car)
#define Second	(Data->cdr->car)
#define Third	(Data->cdr->cdr->car)

extern struct pair NilAtom;
extern struct pair TrueAtom;
extern struct pair *Data;
extern struct pair *Stack;
extern struct pair *User;
extern struct pair *D_REG;

#define A_DIM 	sizeof(void *)

/*---> alloc.c
*/



struct pair *alloc_pair();
struct pair *alloc_cons( struct pair *car, struct pair *cdr);
struct pair *gen_pop( struct pair **stack);
void gen_push( struct pair *a, struct pair **stack);

void dpush_atom( void *car, void *cdr, char kind);


/*---> stack.c
*/

void dpush( struct pair *a);
struct pair * dpop();

void push( struct pair *a);
struct pair * pop();

void rpush();
void rpop();

void drop();
void cdr();
void second_cdr();
void car();
void dup();
void cons();
void value();
void scons();

void swap();
void over();
void nip();
void quote();

void num_eq();
void num_add();
void num_sub();
void num_xor();
void num_mul();
void num_div();

void nil();

void eval();
void apply( char eap);
void apply_prim();
void apply_lambda();
void print_sexpr_f( struct pair *p);

struct pair *init_alloc( struct pair *car, struct pair *cdr, char kind);

#define ref_prim_code( p)	((p)->car)
#define ref_sym_value( s) 	((s)->car)
#define ref_sym_props( s)	((s)->cdr)
#define ref_num_value( s)	((int)((s)->car))

