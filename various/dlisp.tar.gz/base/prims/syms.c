#include"../lisp.h"

void set()	{ ref_sym_value( First) = Second; drop(); drop(); }

void prim_set()	{ mono_op( SYMBOL, set); }

#define ref_sym_props( s )	(( s)->cdr)
#define ref_prop_key( p)	(( p)->car)
#define ref_prop_value( p)	(( p)->cdr->car)

struct pair *getprop( struct pair *props, struct pair *key)
{
	while( props != Nil){
		if( ref_prop_key( props->car ) == key )
			return props->car;
		props = props->cdr;
	}
	return Nil;
}

void prim_get() /* key sym -- value */ 
{
	Second = getprop( ref_sym_props( First), Second );
	Second = ref_prop_value( Second);
	drop();
}
void prim_setprop() /* value key sym -- value */
{
	struct pair *sym = First;
	struct pair *key = Second;
	struct pair *value = Third;
	struct pair *prop;

	prop = getprop( ref_sym_props( sym), key );

	if( prop == Nil){
		dpush( key); dpush( value); couple();
		gen_push( First, &ref_sym_props( sym));
		drop();
	}else{
		ref_prop_value( prop) = value;
	}
	drop(); 
	drop();
}

void fexpr_defun()
{
	struct pair *sym = First;
	rpush();
	fexpr_lambda();
	ref_sym_value( sym) = First;
	rpop();
}
