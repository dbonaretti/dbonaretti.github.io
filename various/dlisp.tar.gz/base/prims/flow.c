#include"../lisp.h"

/*
	( mapcar functional list )
	( mapcan predicate list )
*/

extern void prim_apply();


void rec_mapcar( struct pair *f, struct pair *list) 
{
	if( list != Nil){
		dpush( list ); dpush( f); prim_apply();
		rec_mapcar( f, list->cdr);
		cons();
	}else{
		nil();
	}
}

void prim_mapcar()
{
	rec_mapcar( First, Second); nip(); nip();
}


void fexpr_progn()
{
	dpush( Nil);
	do{
		drop();
		eval();
	}while( Data->cdr != Nil);
}

void fexpr_if()
{
	eval();
	if( dpop() == Nil)
		drop();
	else
		nip();
	eval();
}

/*
	( cond
		( condition action )
		( condition action )
		( condition action )
		( condition action ))
*/


char try() /* ( condition action ) -- Nil/Result */
{
	dup(); car(); eval(); if( First != Nil){
		drop();
		cdr(); car(); eval(); 
		return 1;
	}
	nip();
	return 0;
}

void fexpr_cond() 
{
	struct pair *l;
	while( Data != Nil ){
		if( try())
			return;
		drop();
	}
}
void fexpr_quote()	{	return; }
