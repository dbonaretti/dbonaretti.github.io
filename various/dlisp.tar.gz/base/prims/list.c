#include"../lisp.h"

void prim_cons()	{ if( Second->kind == CONS  || Second == Nil )  scons(); else { drop(); drop(); dpush( Nil);}  }
void prim_car()		{ mono_op( CONS, car); }
void prim_cdr()		{ mono_op( CONS, cdr); }

void prim_list()
{
	push( Data);
	Data = Nil;
	rpop();
}

void prim_revert()
{
	unsigned int n = 0;

	push( Nil);
	while( Data != Nil) 
		gen_push( dpop() , &Stack->car);
	rpop();
}
