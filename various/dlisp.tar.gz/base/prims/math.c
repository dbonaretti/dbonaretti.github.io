#include"../lisp.h"

void prim_add()
{ 
	int t=0;
	while( Data != Nil)
		t += pop_num();
	push_num( t);
}

void prim_eq()	{ if( pop_num() == pop_num() ) 	dpush(True); else dpush(Nil);  }
void prim_sub()	{ push_num( pop_num()-pop_num()); }
void prim_xor()	{ push_num( pop_num()^pop_num()); }
void prim_div()	{ push_num( pop_num()/pop_num()); }
void prim_mul()	{ push_num( pop_num()*pop_num()); }


void lt_drop( struct pair *a, struct pair *b)
{
	if( ref_num_value( a) < ref_num_value( b))
		drop();
	else
		nip();
}
void prim_max()
{
	while( Second != Nil)
		lt_drop( First, Second);
}
void prim_min()
{
	while( Second != Nil)
		lt_drop( Second, First);
}
