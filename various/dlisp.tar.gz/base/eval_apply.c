#include"./lisp.h"

extern void apply_lambda(); 

void caps_apply() /* args func -- retval */
{
	void (*f)() = (void *)(First->car);

	push( Data);
	Data = Second;

	(*f)();

	D_REG = First;
	Data = pop(); drop(); drop();
	dpush( D_REG);
}


void eval_args();

void eval_first_arg()	{ car(); eval(); }
void eval_next_args()	{ cdr(); eval_args(); }

void eval_args() /* a_n l -- a_n a_(n+1) l_(n+1) */
{
	if( First != Nil ){
		dup(); eval_first_arg(); swap();
		eval_next_args();
		cons();
	}
}
void apply_abort()	{   drop(); drop(); dpush( Nil); }

void eap_ea( char eap)	{ if( eap){ rpush(); eval_args(); rpop(); } }

void apply( char eap)
{
	switch(First->kind){
	case NIL:	apply_abort();			break;
	case SYMBOL:	eval(); apply( eap);		break;
	case CONS:	eval(); apply( eap);		break;
	case LAMBDA:	eap_ea( eap); apply_lambda();	break;
	case PRIM: 	eap_ea( eap); caps_apply();	break;
	case FEXPR:	caps_apply();			break;
	default: 	apply_abort();		
	}
}

void prim_apply() 	{ apply(0); }

void cons_decompose()	{  dup(); cdr(); swap(); car(); }
void eval_cons() 	{  cons_decompose(); apply(1);  }
void eval_symbol() 	{  value();  }

void eval()
{
	switch( First->kind){
	case NIL:	First = Nil; 	break;
	case CONS:	eval_cons(); 	break;
	case SYMBOL:	eval_symbol();	break;
	}
}
void prim_eval()	{ eval(); }

/*
ISC License

Copyright 2025 Davide Bonaretti

Permission to use, copy, modify, and/or distribute this 
software for any purpose with or without fee is hereby 
granted, provided that the above copyright notice and 
this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR 
DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE 
INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND 
FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY 
SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR 
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA 
OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, 
NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR 
IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS 
SOFTWARE.
*/
